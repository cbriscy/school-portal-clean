import { getDb } from "../api/queries/connection";
import {
  gradingScale,
  academicSessions,
  terms,
  schoolSettings,
} from "./schema";

async function seed() {
  const db = getDb();

  // Seed grading scale (Nigerian standard)
  const existingGrades = await db.select().from(gradingScale);
  if (existingGrades.length === 0) {
    await db.insert(gradingScale).values([
      { grade: "A", minScore: 70, maxScore: 100, remark: "Excellent" },
      { grade: "B", minScore: 60, maxScore: 69, remark: "Good" },
      { grade: "C", minScore: 50, maxScore: 59, remark: "Credit" },
      { grade: "D", minScore: 45, maxScore: 49, remark: "Pass" },
      { grade: "E", minScore: 40, maxScore: 44, remark: "Fair" },
      { grade: "F", minScore: 0, maxScore: 39, remark: "Fail" },
    ]);
    console.log("Seeded grading scale");
  }

  // Seed default session
  const existingSessions = await db.select().from(academicSessions);
  if (existingSessions.length === 0) {
    await db.insert(academicSessions).values({
      name: "2024/2025",
      startDate: new Date("2024-09-01"),
      endDate: new Date("2025-07-31"),
      isActive: true,
    });
    console.log("Seeded default session");
  }

  // Seed terms for the session
  const existingTerms = await db.select().from(terms);
  if (existingTerms.length === 0) {
    const sessions = await db.select().from(academicSessions);
    const activeSession = sessions.find((s) => s.isActive);
    if (activeSession) {
      await db.insert(terms).values([
        {
          sessionId: activeSession.id,
          name: "1st Term",
          startDate: new Date("2024-09-01"),
          endDate: new Date("2024-12-20"),
          isActive: false,
          isClosed: true,
        },
        {
          sessionId: activeSession.id,
          name: "2nd Term",
          startDate: new Date("2025-01-06"),
          endDate: new Date("2025-04-15"),
          isActive: true,
          isClosed: false,
        },
        {
          sessionId: activeSession.id,
          name: "3rd Term",
          startDate: new Date("2025-05-01"),
          endDate: new Date("2025-07-31"),
          isActive: false,
          isClosed: false,
        },
      ]);
      console.log("Seeded terms");
    }
  }

  // Seed school settings
  const existingSettings = await db.select().from(schoolSettings);
  if (existingSettings.length === 0) {
    await db.insert(schoolSettings).values({
      schoolName: "Meridian Academy",
      address: "123 Education Road, Lagos, Nigeria",
      phone: "+234 800 123 4567",
      email: "info@meridianacademy.edu.ng",
      website: "www.meridianacademy.edu.ng",
      motto: "Knowledge for Excellence",
      principalName: "Dr. A. O. Adebayo",
    });
    console.log("Seeded school settings");
  }

  console.log("Seed complete!");
}

seed().catch(console.error);
