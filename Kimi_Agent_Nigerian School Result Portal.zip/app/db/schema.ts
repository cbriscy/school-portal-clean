import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  int,
  bigint,
  decimal,
  boolean,
  date,
  uniqueIndex,
} from "drizzle-orm/mysql-core";

// ==================== AUTH (from init) ====================
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ==================== ACADEMIC SESSIONS ====================
export const academicSessions = mysqlTable("academic_sessions", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 20 }).notNull(), // e.g. "2024/2025"
  startDate: date("start_date"),
  endDate: date("end_date"),
  isActive: boolean("is_active").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type AcademicSession = typeof academicSessions.$inferSelect;
export type InsertAcademicSession = typeof academicSessions.$inferInsert;

// ==================== TERMS ====================
export const terms = mysqlTable("terms", {
  id: serial("id").primaryKey(),
  sessionId: bigint("session_id", { mode: "number", unsigned: true })
    .notNull()
    .references(() => academicSessions.id),
  name: mysqlEnum("name", ["1st Term", "2nd Term", "3rd Term"]).notNull(),
  startDate: date("start_date"),
  endDate: date("end_date"),
  isActive: boolean("is_active").default(false).notNull(),
  isClosed: boolean("is_closed").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Term = typeof terms.$inferSelect;
export type InsertTerm = typeof terms.$inferInsert;

// ==================== STUDENTS ====================
export const students = mysqlTable("students", {
  id: serial("id").primaryKey(),
  admissionNo: varchar("admission_no", { length: 50 }).notNull().unique(),
  surname: varchar("surname", { length: 100 }).notNull(),
  firstName: varchar("first_name", { length: 100 }).notNull(),
  otherNames: varchar("other_names", { length: 100 }),
  gender: mysqlEnum("gender", ["Male", "Female"]).notNull(),
  dateOfBirth: date("date_of_birth"),
  currentClass: mysqlEnum("current_class", [
    "Pre-Nursery",
    "Nursery 1",
    "Nursery 2",
    "Primary 1",
    "Primary 2",
    "Primary 3",
    "Primary 4",
    "Primary 5",
    "Primary 6",
    "JSS 1",
    "JSS 2",
    "JSS 3",
    "SSS 1",
    "SSS 2",
    "SSS 3",
  ]).notNull(),
  sessionAdmitted: varchar("session_admitted", { length: 20 }),
  status: mysqlEnum("status", ["Active", "Graduated", "Transferred", "Withdrawn"]).default("Active").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type Student = typeof students.$inferSelect;
export type InsertStudent = typeof students.$inferInsert;

// ==================== SUBJECTS ====================
export const subjects = mysqlTable("subjects", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  code: varchar("code", { length: 20 }).notNull().unique(),
  assignmentMax: int("assignment_max").default(10).notNull(),
  testMax: int("test_max").default(30).notNull(),
  examMax: int("exam_max").default(60).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type Subject = typeof subjects.$inferSelect;
export type InsertSubject = typeof subjects.$inferInsert;

// ==================== SUBJECT-CLASS MAPPING ====================
export const subjectClasses = mysqlTable("subject_classes", {
  id: serial("id").primaryKey(),
  subjectId: bigint("subject_id", { mode: "number", unsigned: true })
    .notNull()
    .references(() => subjects.id),
  classLevel: mysqlEnum("class_level", [
    "Pre-Nursery",
    "Nursery 1",
    "Nursery 2",
    "Primary 1",
    "Primary 2",
    "Primary 3",
    "Primary 4",
    "Primary 5",
    "Primary 6",
    "JSS 1",
    "JSS 2",
    "JSS 3",
    "SSS 1",
    "SSS 2",
    "SSS 3",
  ]).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("subject_class_unique").on(table.subjectId, table.classLevel),
]);

export type SubjectClass = typeof subjectClasses.$inferSelect;
export type InsertSubjectClass = typeof subjectClasses.$inferInsert;

// ==================== SCORES ====================
export const scores = mysqlTable("scores", {
  id: serial("id").primaryKey(),
  studentId: bigint("student_id", { mode: "number", unsigned: true })
    .notNull()
    .references(() => students.id),
  subjectId: bigint("subject_id", { mode: "number", unsigned: true })
    .notNull()
    .references(() => subjects.id),
  sessionId: bigint("session_id", { mode: "number", unsigned: true })
    .notNull()
    .references(() => academicSessions.id),
  termId: bigint("term_id", { mode: "number", unsigned: true })
    .notNull()
    .references(() => terms.id),
  assignmentScore: decimal("assignment_score", { precision: 5, scale: 2 }).default("0"),
  testScore: decimal("test_score", { precision: 5, scale: 2 }).default("0"),
  examScore: decimal("exam_score", { precision: 5, scale: 2 }).default("0"),
  totalScore: decimal("total_score", { precision: 5, scale: 2 }).default("0"),
  grade: varchar("grade", { length: 5 }),
  remark: varchar("remark", { length: 50 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
}, (table) => [
  uniqueIndex("score_unique").on(table.studentId, table.subjectId, table.sessionId, table.termId),
]);

export type Score = typeof scores.$inferSelect;
export type InsertScore = typeof scores.$inferInsert;

// ==================== GRADING SCALE ====================
export const gradingScale = mysqlTable("grading_scale", {
  id: serial("id").primaryKey(),
  grade: varchar("grade", { length: 5 }).notNull().unique(),
  minScore: int("min_score").notNull(),
  maxScore: int("max_score").notNull(),
  remark: varchar("remark", { length: 50 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type GradingScale = typeof gradingScale.$inferSelect;
export type InsertGradingScale = typeof gradingScale.$inferInsert;

// ==================== SCHOOL SETTINGS ====================
export const schoolSettings = mysqlTable("school_settings", {
  id: serial("id").primaryKey(),
  schoolName: varchar("school_name", { length: 200 }).default("Meridian Academy"),
  address: text("address"),
  phone: varchar("phone", { length: 50 }),
  email: varchar("email", { length: 100 }),
  website: varchar("website", { length: 100 }),
  motto: varchar("motto", { length: 200 }),
  principalName: varchar("principal_name", { length: 100 }),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type SchoolSetting = typeof schoolSettings.$inferSelect;
export type InsertSchoolSetting = typeof schoolSettings.$inferInsert;
