import { useState } from "react";
import { Link, useLocation } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import {
  LayoutDashboard,
  Users,
  PenSquare,
  FileText,
  BookOpen,
  SlidersHorizontal,
  Calendar,
  Settings,
  LogOut,
  Menu,
  X,
  GraduationCap,
} from "lucide-react";

const teacherNav = [
  { label: "Dashboard", path: "/", icon: LayoutDashboard },
  { label: "Students", path: "/students", icon: Users },
  { label: "Enter Scores", path: "/scores", icon: PenSquare },
  { label: "View Results", path: "/results", icon: FileText },
];

const adminNav = [
  { label: "Subjects", path: "/subjects", icon: BookOpen },
  { label: "Grading Scale", path: "/grading", icon: SlidersHorizontal },
  { label: "Sessions", path: "/sessions", icon: Calendar },
  { label: "Settings", path: "/settings", icon: Settings },
];

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const { user, logout } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  const isActive = (path: string) => {
    if (path === "/") return location.pathname === "/";
    return location.pathname.startsWith(path);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[var(--canvas)]">
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed lg:static inset-y-0 left-0 z-50
          w-[240px] bg-white border-r border-[var(--border-color)]
          flex flex-col transition-transform duration-200
          ${mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}
        `}
      >
        {/* Logo */}
        <div className="flex items-center gap-2 px-4 h-14 border-b border-[var(--border-color)]">
          <div className="w-8 h-8 rounded-lg bg-[var(--accent-color)] flex items-center justify-center">
            <GraduationCap className="w-5 h-5 text-white" />
          </div>
          <span className="text-base font-semibold text-[var(--text-primary)]">
            Meridian
          </span>
          <button
            className="ml-auto lg:hidden p-1 rounded hover:bg-gray-100"
            onClick={() => setMobileOpen(false)}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-6">
          {/* Teacher Section */}
          <div>
            <div className="px-3 mb-2">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                Teacher
              </span>
            </div>
            <div className="space-y-1">
              {teacherNav.map((item) => {
                const Icon = item.icon;
                const active = isActive(item.path);
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setMobileOpen(false)}
                    className={`
                      flex items-center gap-3 px-3 h-10 rounded-md text-sm
                      transition-colors duration-150
                      ${active
                        ? "bg-[var(--accent-light)] text-[var(--accent-dark)] font-semibold"
                        : "text-[var(--sidebar-text)] hover:bg-[var(--surface-secondary)]"
                      }
                    `}
                  >
                    <Icon className="w-[18px] h-[18px] flex-shrink-0" />
                    <span>{item.label}</span>
                  </Link>
                );
              })}
            </div>
          </div>

          {/* Admin Section */}
          <div>
            <div className="px-3 mb-2">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                Admin
              </span>
            </div>
            <div className="space-y-1">
              {adminNav.map((item) => {
                const Icon = item.icon;
                const active = isActive(item.path);
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setMobileOpen(false)}
                    className={`
                      flex items-center gap-3 px-3 h-10 rounded-md text-sm
                      transition-colors duration-150
                      ${active
                        ? "bg-[var(--accent-light)] text-[var(--accent-dark)] font-semibold"
                        : "text-[var(--sidebar-text)] hover:bg-[var(--surface-secondary)]"
                      }
                    `}
                  >
                    <Icon className="w-[18px] h-[18px] flex-shrink-0" />
                    <span>{item.label}</span>
                  </Link>
                );
              })}
            </div>
          </div>
        </nav>

        {/* Footer */}
        <div className="border-t border-[var(--border-color)] p-3 space-y-1">
          {user && (
            <div className="flex items-center gap-2 px-3 py-2">
              <div className="w-8 h-8 rounded-full bg-[var(--accent-light)] flex items-center justify-center">
                <span className="text-xs font-semibold text-[var(--accent-dark)]">
                  {user.name?.charAt(0) ?? "T"}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-[var(--text-primary)] truncate">
                  {user.name ?? "Teacher"}
                </p>
                <p className="text-[11px] text-[var(--text-muted)]">Teacher</p>
              </div>
            </div>
          )}
          <button
            onClick={logout}
            className="flex items-center gap-3 px-3 h-10 w-full rounded-md text-sm text-[var(--sidebar-text)] hover:bg-[var(--surface-secondary)] transition-colors"
          >
            <LogOut className="w-[18px] h-[18px]" />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Bar */}
        <header className="h-14 bg-white border-b border-[var(--border-color)] flex items-center px-4 lg:px-6 flex-shrink-0">
          <button
            className="lg:hidden p-2 -ml-2 rounded-md hover:bg-gray-100"
            onClick={() => setMobileOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex-1" />
          <div className="flex items-center gap-3">
            <span className="hidden sm:inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-[var(--accent-light)] text-[var(--accent-dark)]">
              2024/2025 — 2nd Term
            </span>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-y-auto p-4 lg:p-6">{children}</div>
      </main>
    </div>
  );
}
