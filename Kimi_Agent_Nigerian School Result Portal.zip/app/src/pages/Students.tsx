import { useState } from "react";
import { trpc } from "@/providers/trpc";
import {
  Search,
  Plus,
  Eye,
  Pencil,
  Trash2,
  X,
  ChevronLeft,
  ChevronRight,
  GraduationCap,
} from "lucide-react";

const CLASS_OPTIONS = [
  "All",
  "Pre-Nursery",
  "Nursery 1",
  "Nursery 2",
  "Primary 1",
  "Primary 2",
  "Primary 3",
  "Primary 4",
  "Primary 5",
  "Primary 6",
  "JSS 1",
  "JSS 2",
  "JSS 3",
  "SSS 1",
  "SSS 2",
  "SSS 3",
];

const GENDER_OPTIONS = ["Male", "Female"];
const STATUS_OPTIONS = ["Active", "Graduated", "Transferred", "Withdrawn"];

export default function Students() {
  const [classFilter, setClassFilter] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [page, setPage] = useState(1);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showViewDrawer, setShowViewDrawer] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<any>(null);

  // Form state
  const [formData, setFormData] = useState({
    surname: "",
    firstName: "",
    otherNames: "",
    gender: "Male" as "Male" | "Female",
    dateOfBirth: "",
    currentClass: "Primary 1" as any,
    sessionAdmitted: "",
  });

  const utils = trpc.useUtils();

  const { data, isLoading } = trpc.student.list.useQuery({
    class: classFilter === "All" ? undefined : classFilter,
    search: searchQuery || undefined,
    page,
    limit: 25,
  });

  const createMutation = trpc.student.create.useMutation({
    onSuccess: () => {
      utils.student.list.invalidate();
      utils.dashboard.stats.invalidate();
      setShowAddModal(false);
      resetForm();
    },
  });

  const updateMutation = trpc.student.update.useMutation({
    onSuccess: () => {
      utils.student.list.invalidate();
      setShowEditModal(false);
      setSelectedStudent(null);
    },
  });

  const deleteMutation = trpc.student.delete.useMutation({
    onSuccess: () => {
      utils.student.list.invalidate();
      utils.dashboard.stats.invalidate();
      setShowDeleteConfirm(false);
      setSelectedStudent(null);
    },
  });

  const { data: studentDetail } = trpc.student.getById.useQuery(
    { id: selectedStudent?.id ?? 0 },
    { enabled: !!selectedStudent?.id && showViewDrawer }
  );

  const resetForm = () => {
    setFormData({
      surname: "",
      firstName: "",
      otherNames: "",
      gender: "Male",
      dateOfBirth: "",
      currentClass: "Primary 1",
      sessionAdmitted: "",
    });
  };

  const openEdit = (student: any) => {
    setSelectedStudent(student);
    setFormData({
      surname: student.surname,
      firstName: student.firstName,
      otherNames: student.otherNames ?? "",
      gender: student.gender,
      dateOfBirth: student.dateOfBirth
        ? new Date(student.dateOfBirth).toISOString().split("T")[0]
        : "",
      currentClass: student.currentClass,
      sessionAdmitted: student.sessionAdmitted ?? "",
    });
    setShowEditModal(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.surname || !formData.firstName) return;
    createMutation.mutate(formData);
  };

  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent) return;
    updateMutation.mutate({
      id: selectedStudent.id,
      ...formData,
    });
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-xl font-semibold text-[var(--text-primary)]">Students</h1>
        <button
          onClick={() => {
            resetForm();
            setShowAddModal(true);
          }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-[var(--accent-color)] text-white text-sm font-medium hover:bg-[var(--accent-hover)] transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add Student
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <select
          value={classFilter}
          onChange={(e) => { setClassFilter(e.target.value); setPage(1); }}
          className="h-10 px-3 rounded-md border border-[var(--border-color)] bg-white text-sm text-[var(--text-primary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
        >
          {CLASS_OPTIONS.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--text-muted)]" />
          <input
            type="text"
            placeholder="Search by name or admission no."
            value={searchQuery}
            onChange={(e) => { setSearchQuery(e.target.value); setPage(1); }}
            className="w-full h-10 pl-9 pr-3 rounded-md border border-[var(--border-color)] bg-white text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg border border-[var(--border-color)] shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[var(--border-color)] bg-[var(--surface-secondary)]">
                <th className="text-left px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                  Admission No.
                </th>
                <th className="text-left px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                  Name
                </th>
                <th className="text-left px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                  Class
                </th>
                <th className="text-left px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                  Gender
                </th>
                <th className="text-left px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                  Status
                </th>
                <th className="text-right px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                  Action
                </th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                [...Array(5)].map((_, i) => (
                  <tr key={i} className="border-b border-[var(--border-subtle)]">
                    {[...Array(6)].map((_, j) => (
                      <td key={j} className="px-4 py-3">
                        <div className="h-4 bg-gray-200 rounded animate-pulse" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : data?.students.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-12 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <GraduationCap className="w-12 h-12 text-[var(--text-muted)]" />
                      <p className="text-sm text-[var(--text-muted)]">
                        No students found. Add your first student to get started.
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                data?.students.map((student) => (
                  <tr
                    key={student.id}
                    className="border-b border-[var(--border-subtle)] hover:bg-[var(--surface-secondary)] transition-colors"
                  >
                    <td className="px-4 py-3 text-sm font-medium text-[var(--text-primary)]">
                      {student.admissionNo}
                    </td>
                    <td className="px-4 py-3 text-sm text-[var(--text-secondary)]">
                      {student.surname} {student.firstName}
                    </td>
                    <td className="px-4 py-3">
                      <span className="inline-flex px-2 py-0.5 rounded-full text-xs font-medium bg-[var(--accent-light)] text-[var(--accent-dark)]">
                        {student.currentClass}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-[var(--text-secondary)]">
                      {student.gender}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${
                          student.status === "Active"
                            ? "bg-emerald-50 text-emerald-600"
                            : student.status === "Graduated"
                            ? "bg-blue-50 text-blue-600"
                            : "bg-gray-100 text-gray-600"
                        }`}
                      >
                        {student.status}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => {
                            setSelectedStudent(student);
                            setShowViewDrawer(true);
                          }}
                          className="p-1.5 rounded-md hover:bg-gray-100 text-[var(--text-muted)] hover:text-[var(--accent-color)] transition-colors"
                          title="View"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => openEdit(student)}
                          className="p-1.5 rounded-md hover:bg-gray-100 text-[var(--text-muted)] hover:text-[var(--info)] transition-colors"
                          title="Edit"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            setSelectedStudent(student);
                            setShowDeleteConfirm(true);
                          }}
                          className="p-1.5 rounded-md hover:bg-gray-100 text-[var(--text-muted)] hover:text-[var(--danger)] transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {data && data.totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-[var(--border-color)]">
            <p className="text-xs text-[var(--text-muted)]">
              Showing {((page - 1) * 25) + 1} - {Math.min(page * 25, data.total)} of {data.total}
            </p>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="p-1.5 rounded-md hover:bg-gray-100 disabled:opacity-40 text-[var(--text-secondary)]"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="text-xs text-[var(--text-muted)] px-2">
                Page {page} of {data.totalPages}
              </span>
              <button
                onClick={() => setPage((p) => Math.min(data.totalPages, p + 1))}
                disabled={page === data.totalPages}
                className="p-1.5 rounded-md hover:bg-gray-100 disabled:opacity-40 text-[var(--text-secondary)]"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-4 py-3 border-b border-[var(--border-color)]">
              <h3 className="text-base font-semibold text-[var(--text-primary)]">
                Add New Student
              </h3>
              <button
                onClick={() => { setShowAddModal(false); resetForm(); }}
                className="p-1 rounded-md hover:bg-gray-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-4 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                    Surname *
                  </label>
                  <input
                    required
                    value={formData.surname}
                    onChange={(e) => setFormData({ ...formData, surname: e.target.value })}
                    className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                    First Name *
                  </label>
                  <input
                    required
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                  Other Names
                </label>
                <input
                  value={formData.otherNames}
                  onChange={(e) => setFormData({ ...formData, otherNames: e.target.value })}
                  className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                    Gender *
                  </label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value as "Male" | "Female" })}
                    className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                  >
                    {GENDER_OPTIONS.map((g) => (
                      <option key={g} value={g}>{g}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                    Date of Birth
                  </label>
                  <input
                    type="date"
                    value={formData.dateOfBirth}
                    onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                    className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                    Class *
                  </label>
                  <select
                    value={formData.currentClass}
                    onChange={(e) => setFormData({ ...formData, currentClass: e.target.value })}
                    className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                  >
                    {CLASS_OPTIONS.filter((c) => c !== "All").map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                    Session Admitted
                  </label>
                  <input
                    placeholder="e.g. 2024/2025"
                    value={formData.sessionAdmitted}
                    onChange={(e) => setFormData({ ...formData, sessionAdmitted: e.target.value })}
                    className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => { setShowAddModal(false); resetForm(); }}
                  className="px-4 py-2 rounded-md border border-[var(--border-color)] text-sm font-medium text-[var(--text-secondary)] hover:bg-[var(--surface-secondary)]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={createMutation.isPending}
                  className="px-4 py-2 rounded-md bg-[var(--accent-color)] text-white text-sm font-medium hover:bg-[var(--accent-hover)] disabled:opacity-50"
                >
                  {createMutation.isPending ? "Saving..." : "Save Student"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {showEditModal && selectedStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-md">
            <div className="flex items-center justify-between px-4 py-3 border-b border-[var(--border-color)]">
              <h3 className="text-base font-semibold text-[var(--text-primary)]">
                Edit Student
              </h3>
              <button
                onClick={() => { setShowEditModal(false); setSelectedStudent(null); }}
                className="p-1 rounded-md hover:bg-gray-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleUpdate} className="p-4 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                    Surname
                  </label>
                  <input
                    value={formData.surname}
                    onChange={(e) => setFormData({ ...formData, surname: e.target.value })}
                    className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                    First Name
                  </label>
                  <input
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                    Gender
                  </label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value as "Male" | "Female" })}
                    className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                  >
                    {GENDER_OPTIONS.map((g) => (
                      <option key={g} value={g}>{g}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                    Class
                  </label>
                  <select
                    value={formData.currentClass}
                    onChange={(e) => setFormData({ ...formData, currentClass: e.target.value })}
                    className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                  >
                    {CLASS_OPTIONS.filter((c) => c !== "All").map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                  Status
                </label>
                <select
                  value={selectedStudent.status}
                  onChange={(e) =>
                    setSelectedStudent({ ...selectedStudent, status: e.target.value })
                  }
                  className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                >
                  {STATUS_OPTIONS.map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => { setShowEditModal(false); setSelectedStudent(null); }}
                  className="px-4 py-2 rounded-md border border-[var(--border-color)] text-sm font-medium text-[var(--text-secondary)] hover:bg-[var(--surface-secondary)]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={updateMutation.isPending}
                  className="px-4 py-2 rounded-md bg-[var(--accent-color)] text-white text-sm font-medium hover:bg-[var(--accent-hover)] disabled:opacity-50"
                >
                  {updateMutation.isPending ? "Updating..." : "Update"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Drawer */}
      {showViewDrawer && (
        <div className="fixed inset-0 z-50">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => { setShowViewDrawer(false); setSelectedStudent(null); }}
          />
          <div className="absolute right-0 top-0 bottom-0 w-full max-w-md bg-white shadow-lg overflow-y-auto">
            <div className="flex items-center justify-between px-4 py-3 border-b border-[var(--border-color)]">
              <h3 className="text-base font-semibold text-[var(--text-primary)]">
                Student Details
              </h3>
              <button
                onClick={() => { setShowViewDrawer(false); setSelectedStudent(null); }}
                className="p-1 rounded-md hover:bg-gray-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            {studentDetail && (
              <div className="p-4 space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-[var(--accent-light)] flex items-center justify-center">
                    <span className="text-xl font-bold text-[var(--accent-dark)]">
                      {studentDetail.firstName?.[0]}{studentDetail.surname?.[0]}
                    </span>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-[var(--text-primary)]">
                      {studentDetail.surname} {studentDetail.firstName}
                    </h4>
                    <p className="text-sm text-[var(--text-muted)]">
                      {studentDetail.admissionNo}
                    </p>
                  </div>
                </div>
                <div className="space-y-3">
                  {[
                    { label: "Class", value: studentDetail.currentClass },
                    { label: "Gender", value: studentDetail.gender },
                    { label: "Status", value: studentDetail.status },
                    { label: "Date of Birth", value: studentDetail.dateOfBirth ? new Date(studentDetail.dateOfBirth).toLocaleDateString() : "N/A" },
                    { label: "Session Admitted", value: studentDetail.sessionAdmitted ?? "N/A" },
                  ].map((item) => (
                    <div key={item.label} className="flex justify-between py-2 border-b border-[var(--border-subtle)]">
                      <span className="text-sm text-[var(--text-muted)]">{item.label}</span>
                      <span className="text-sm font-medium text-[var(--text-primary)]">{item.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {showDeleteConfirm && selectedStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-sm p-4">
            <h3 className="text-base font-semibold text-[var(--text-primary)] mb-2">
              Delete Student
            </h3>
            <p className="text-sm text-[var(--text-secondary)] mb-4">
              Are you sure you want to delete <strong>{selectedStudent.surname} {selectedStudent.firstName}</strong>? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => { setShowDeleteConfirm(false); setSelectedStudent(null); }}
                className="px-4 py-2 rounded-md border border-[var(--border-color)] text-sm font-medium text-[var(--text-secondary)] hover:bg-[var(--surface-secondary)]"
              >
                Cancel
              </button>
              <button
                onClick={() => deleteMutation.mutate({ id: selectedStudent.id })}
                disabled={deleteMutation.isPending}
                className="px-4 py-2 rounded-md bg-[var(--danger)] text-white text-sm font-medium hover:bg-red-700 disabled:opacity-50"
              >
                {deleteMutation.isPending ? "Deleting..." : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
