import { useState, useEffect } from "react";
import { trpc } from "@/providers/trpc";
import { toast } from "sonner";
import { Settings, Save, Loader2 } from "lucide-react";

export default function SettingsPage() {
  const utils = trpc.useUtils();
  const { data: schoolSettings, isLoading } = trpc.settings.getSchoolSettings.useQuery();

  const [formData, setFormData] = useState({
    schoolName: "",
    address: "",
    phone: "",
    email: "",
    website: "",
    motto: "",
    principalName: "",
  });

  useEffect(() => {
    if (schoolSettings) {
      setFormData({
        schoolName: schoolSettings.schoolName ?? "",
        address: schoolSettings.address ?? "",
        phone: schoolSettings.phone ?? "",
        email: schoolSettings.email ?? "",
        website: schoolSettings.website ?? "",
        motto: schoolSettings.motto ?? "",
        principalName: schoolSettings.principalName ?? "",
      });
    }
  }, [schoolSettings]);

  const updateMutation = trpc.settings.updateSchoolSettings.useMutation({
    onSuccess: () => {
      utils.settings.getSchoolSettings.invalidate();
      toast.success("Settings saved!");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateMutation.mutate(formData);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-48">
        <Loader2 className="w-6 h-6 animate-spin text-[var(--accent-color)]" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-[var(--accent-light)] flex items-center justify-center">
          <Settings className="w-5 h-5 text-[var(--accent-color)]" />
        </div>
        <div>
          <h1 className="text-xl font-semibold text-[var(--text-primary)]">School Settings</h1>
          <p className="text-sm text-[var(--text-muted)]">
            Manage your school profile information.
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-lg border border-[var(--border-color)] shadow-sm p-6 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
              School Name
            </label>
            <input
              value={formData.schoolName}
              onChange={(e) => setFormData({ ...formData, schoolName: e.target.value })}
              className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
              Principal's Name
            </label>
            <input
              value={formData.principalName}
              onChange={(e) => setFormData({ ...formData, principalName: e.target.value })}
              className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
            Address
          </label>
          <textarea
            value={formData.address}
            onChange={(e) => setFormData({ ...formData, address: e.target.value })}
            rows={2}
            className="w-full px-3 py-2 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)] resize-none"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
              Phone
            </label>
            <input
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
              Email
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
              Website
            </label>
            <input
              value={formData.website}
              onChange={(e) => setFormData({ ...formData, website: e.target.value })}
              className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
            School Motto
          </label>
          <input
            value={formData.motto}
            onChange={(e) => setFormData({ ...formData, motto: e.target.value })}
            className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
          />
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={updateMutation.isPending}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-[var(--accent-color)] text-white text-sm font-medium hover:bg-[var(--accent-hover)] disabled:opacity-50"
          >
            {updateMutation.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            Save Settings
          </button>
        </div>
      </form>
    </div>
  );
}
