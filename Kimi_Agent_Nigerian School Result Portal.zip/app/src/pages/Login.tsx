import { GraduationCap } from "lucide-react";

function getOAuthUrl() {
  const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

export default function Login() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[var(--canvas)] p-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-[var(--accent-color)] flex items-center justify-center mx-auto mb-4 shadow-lg">
            <GraduationCap className="w-9 h-9 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-[var(--text-primary)]">Meridian Academy</h1>
          <p className="text-sm text-[var(--text-muted)] mt-1">
            School Result Management Portal
          </p>
        </div>

        {/* Login Card */}
        <div className="bg-white rounded-xl border border-[var(--border-color)] shadow-sm p-6">
          <h2 className="text-base font-semibold text-[var(--text-primary)] text-center mb-1">
            Teacher Login
          </h2>
          <p className="text-xs text-[var(--text-muted)] text-center mb-6">
            Sign in to manage students, enter scores, and view results.
          </p>

          <button
            onClick={() => {
              window.location.href = getOAuthUrl();
            }}
            className="w-full h-11 rounded-lg bg-[var(--accent-color)] text-white text-sm font-semibold hover:bg-[var(--accent-hover)] transition-colors shadow-sm"
          >
            Sign in with Kimi
          </button>

          <div className="mt-6 pt-4 border-t border-[var(--border-subtle)]">
            <div className="flex items-center gap-2 justify-center text-xs text-[var(--text-muted)]">
              <GraduationCap className="w-3 h-3" />
              <span>Nigerian Pre-Nursery to SSS Result System</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <p className="text-center text-xs text-[var(--text-muted)] mt-6">
          &copy; {new Date().getFullYear()} Meridian Academy. All rights reserved.
        </p>
      </div>
    </div>
  );
}
