import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import {
  Users,
  BookOpen,
  CheckCircle,
  TrendingUp,
  AlertTriangle,
  ArrowRight,
  GraduationCap,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

export default function Dashboard() {
  const navigate = useNavigate();
  const { data: stats, isLoading } = trpc.dashboard.stats.useQuery();

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="h-32 rounded-lg bg-gray-200 animate-pulse" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-24 rounded-lg bg-gray-200 animate-pulse" />
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="h-64 rounded-lg bg-gray-200 animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  const statCards = [
    {
      label: "Total Students",
      value: stats?.totalStudents ?? 0,
      icon: Users,
      color: "bg-blue-50 text-blue-600",
    },
    {
      label: "Total Subjects",
      value: stats?.totalSubjects ?? 0,
      icon: BookOpen,
      color: "bg-emerald-50 text-emerald-600",
    },
    {
      label: "Scores Entered",
      value: stats?.totalScoresEntered ?? 0,
      icon: CheckCircle,
      color: "bg-amber-50 text-amber-600",
    },
    {
      label: "Classes",
      value: stats?.classDistribution?.length ?? 0,
      icon: TrendingUp,
      color: "bg-purple-50 text-purple-600",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Hero Banner */}
      <div className="hero-gradient rounded-lg p-6 lg:p-8 relative overflow-hidden">
        <div className="relative z-10">
          <h1 className="text-xl lg:text-2xl font-bold text-[var(--text-primary)] mb-1">
            Welcome back, {stats?.activeSession ? "Teacher" : "Teacher"}
          </h1>
          <p className="text-sm text-[var(--text-secondary)]">
            {stats?.activeSession?.name ?? "2024/2025"} Academic Session —{" "}
            {stats?.activeTerm?.name ?? "2nd Term"}
          </p>
          <div className="flex flex-wrap gap-3 mt-4">
            <span className="inline-flex items-center px-3 py-1.5 rounded-lg bg-white/80 text-sm font-medium text-[var(--text-primary)]">
              {stats?.totalStudents ?? 0} Students
            </span>
            <span className="inline-flex items-center px-3 py-1.5 rounded-lg bg-white/80 text-sm font-medium text-[var(--text-primary)]">
              {stats?.classDistribution?.length ?? 0} Classes
            </span>
            <span className="inline-flex items-center px-3 py-1.5 rounded-lg bg-white/80 text-sm font-medium text-[var(--text-primary)]">
              {stats?.totalSubjects ?? 0} Subjects
            </span>
          </div>
        </div>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.label}
              className="bg-white rounded-lg border border-[var(--border-color)] p-4 shadow-sm"
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg ${card.color} flex items-center justify-center`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-[11px] font-medium uppercase tracking-wider text-[var(--text-muted)]">
                    {card.label}
                  </p>
                  <p className="text-2xl font-bold text-[var(--text-primary)]">
                    {card.value}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts and Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        {/* Class Performance Chart */}
        <div className="lg:col-span-3 bg-white rounded-lg border border-[var(--border-color)] p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-[var(--text-primary)] mb-4">
            Class Performance Overview
          </h3>
          {stats?.classAverages && stats.classAverages.length > 0 ? (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={stats.classAverages}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                <XAxis
                  dataKey="class"
                  tick={{ fontSize: 11, fill: "#94A3B8" }}
                  axisLine={false}
                  tickLine={false}
                  angle={-30}
                  textAnchor="end"
                  height={60}
                />
                <YAxis
                  tick={{ fontSize: 11, fill: "#94A3B8" }}
                  axisLine={false}
                  tickLine={false}
                  domain={[0, 100]}
                />
                <Tooltip
                  contentStyle={{
                    borderRadius: 8,
                    border: "1px solid #E2E8F0",
                    fontSize: 13,
                  }}
                />
                <Bar
                  dataKey="avgScore"
                  fill="#D97706"
                  radius={[4, 4, 0, 0]}
                  name="Avg Score"
                />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[240px] flex items-center justify-center text-[var(--text-muted)] text-sm">
              No performance data yet
            </div>
          )}
        </div>

        {/* Recent Scores */}
        <div className="lg:col-span-2 bg-white rounded-lg border border-[var(--border-color)] p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-[var(--text-primary)] mb-4">
            Recent Score Entries
          </h3>
          {stats?.recentScores && stats.recentScores.length > 0 ? (
            <div className="space-y-3 max-h-[240px] overflow-y-auto">
              {stats.recentScores.map((score) => (
                <div
                  key={score.id}
                  className="flex items-center justify-between py-2 border-b border-[var(--border-subtle)] last:border-0"
                >
                  <div>
                    <p className="text-sm font-medium text-[var(--text-primary)]">
                      {score.studentName}
                    </p>
                    <p className="text-xs text-[var(--text-muted)]">
                      {score.subjectName}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-[var(--accent-light)] text-[var(--accent-dark)]">
                      {score.totalScore ?? 0}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="h-[200px] flex items-center justify-center text-[var(--text-muted)] text-sm">
              No scores entered yet
            </div>
          )}
        </div>
      </div>

      {/* Incomplete Results */}
      {stats?.incompleteStudents && stats.incompleteStudents.length > 0 && (
        <div className="bg-white rounded-lg border border-[var(--border-color)] p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-4 h-4 text-[var(--warning)]" />
            <h3 className="text-sm font-semibold text-[var(--text-primary)]">
              Students with Incomplete Results
            </h3>
          </div>
          <div className="space-y-2">
            {stats.incompleteStudents.slice(0, 5).map((student) => (
              <div
                key={student.id}
                className="flex items-center justify-between py-2 px-3 rounded-md bg-[var(--warning-light)]"
              >
                <div className="flex items-center gap-3">
                  <span className="text-sm font-medium text-[var(--text-primary)]">
                    {student.name}
                  </span>
                  <span className="text-xs text-[var(--text-muted)]">
                    {student.admissionNo}
                  </span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-white text-[var(--text-secondary)]">
                    {student.class}
                  </span>
                </div>
                <button
                  onClick={() => navigate("/scores")}
                  className="text-xs font-medium text-[var(--accent-color)] hover:text-[var(--accent-hover)] flex items-center gap-1"
                >
                  Enter Scores
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Empty state prompt */}
      {(!stats?.totalStudents || stats.totalStudents === 0) && (
        <div className="bg-white rounded-lg border border-[var(--border-color)] p-8 shadow-sm text-center">
          <div className="w-16 h-16 rounded-full bg-[var(--accent-light)] flex items-center justify-center mx-auto mb-4">
            <GraduationCap className="w-8 h-8 text-[var(--accent-color)]" />
          </div>
          <h3 className="text-lg font-semibold text-[var(--text-primary)] mb-2">
            Get Started with Meridian Academy
          </h3>
          <p className="text-sm text-[var(--text-secondary)] mb-6 max-w-md mx-auto">
            Start by adding students to the system. Once you have students, you can enter scores and generate results.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <button
              onClick={() => navigate("/students")}
              className="px-4 py-2 rounded-md bg-[var(--accent-color)] text-white text-sm font-medium hover:bg-[var(--accent-hover)] transition-colors"
            >
              Add Students
            </button>
            <button
              onClick={() => navigate("/subjects")}
              className="px-4 py-2 rounded-md border border-[var(--border-color)] text-sm font-medium text-[var(--text-secondary)] hover:bg-[var(--surface-secondary)] transition-colors"
            >
              Set Up Subjects
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
