import { useState, useMemo } from "react";
import { trpc } from "@/providers/trpc";
import { toast } from "sonner";
import { Loader2, Save, CheckCircle } from "lucide-react";

const CLASS_OPTIONS = [
  "Pre-Nursery", "Nursery 1", "Nursery 2",
  "Primary 1", "Primary 2", "Primary 3", "Primary 4", "Primary 5", "Primary 6",
  "JSS 1", "JSS 2", "JSS 3",
  "SSS 1", "SSS 2", "SSS 3",
];

export default function EnterScores() {
  const utils = trpc.useUtils();
  const [sessionId, setSessionId] = useState<number>(0);
  const [termId, setTermId] = useState<number>(0);
  const [classLevel, setClassLevel] = useState("");
  const [subjectId, setSubjectId] = useState<number>(0);
  const [scoreData, setScoreData] = useState<Record<number, { assignment: string; test: string; exam: string }>>({});
  const [hasChanges, setHasChanges] = useState(false);

  // Fetch sessions and terms
  const { data: sessions } = trpc.session.listSessions.useQuery();
  const { data: terms } = trpc.session.listTerms.useQuery(
    sessionId ? { sessionId } : undefined,
    { enabled: sessionId > 0 }
  );
  const { data: subjectsData } = trpc.subject.getByClass.useQuery(
    { classLevel },
    { enabled: classLevel.length > 0 }
  );

  // Fetch students and existing scores
  const { data: scoreListData, isLoading: loadingScores } = trpc.score.getByClassSubject.useQuery(
    { sessionId, termId, classLevel, subjectId },
    { enabled: sessionId > 0 && termId > 0 && classLevel.length > 0 && subjectId > 0 }
  );

  const saveMutation = trpc.score.saveScores.useMutation({
    onSuccess: () => {
      utils.score.getByClassSubject.invalidate();
      utils.dashboard.stats.invalidate();
      setHasChanges(false);
      toast.success("Scores saved successfully!");
    },
    onError: () => {
      toast.error("Failed to save scores. Please try again.");
    },
  });

  // Initialize score data when students/scores load
  useMemo(() => {
    if (scoreListData?.students) {
      const initial: Record<number, { assignment: string; test: string; exam: string }> = {};
      scoreListData.students.forEach((student) => {
        const existingScore = scoreListData.scores.find((s) => s.studentId === student.id);
        initial[student.id] = {
          assignment: existingScore?.assignmentScore ? String(existingScore.assignmentScore) : "",
          test: existingScore?.testScore ? String(existingScore.testScore) : "",
          exam: existingScore?.examScore ? String(existingScore.examScore) : "",
        };
      });
      setScoreData(initial);
    }
  }, [scoreListData]);

  const updateScore = (studentId: number, field: "assignment" | "test" | "exam", value: string) => {
    // Allow only numbers
    if (value !== "" && !/^\d*\.?\d*$/.test(value)) return;
    const num = parseFloat(value);
    if (value !== "" && num < 0) return;

    setScoreData((prev) => ({
      ...prev,
      [studentId]: { ...prev[studentId], [field]: value },
    }));
    setHasChanges(true);
  };

  const getTotal = (studentId: number) => {
    const s = scoreData[studentId];
    if (!s) return 0;
    const a = parseFloat(s.assignment) || 0;
    const t = parseFloat(s.test) || 0;
    const e = parseFloat(s.exam) || 0;
    return a + t + e;
  };

  const handleSave = () => {
    if (!sessionId || !termId || !subjectId) {
      toast.error("Please select session, term, class, and subject");
      return;
    }

    const scores = Object.entries(scoreData)
      .filter(([, data]) => data.assignment || data.test || data.exam)
      .map(([studentId, data]) => ({
        studentId: Number(studentId),
        assignmentScore: parseFloat(data.assignment) || 0,
        testScore: parseFloat(data.test) || 0,
        examScore: parseFloat(data.exam) || 0,
      }));

    if (scores.length === 0) {
      toast.error("No scores to save");
      return;
    }

    saveMutation.mutate({ sessionId, termId, subjectId, scores });
  };

  const canLoadStudents = sessionId > 0 && termId > 0 && classLevel && subjectId > 0;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-xl font-semibold text-[var(--text-primary)]">Enter Scores</h1>
        {hasChanges && (
          <div className="flex items-center gap-2 text-sm text-[var(--accent-color)]">
            <div className="w-2 h-2 rounded-full bg-[var(--accent-color)] animate-pulse" />
            Unsaved changes
          </div>
        )}
      </div>

      {/* Selection Form */}
      <div className="bg-white rounded-lg border border-[var(--border-color)] p-4 shadow-sm">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
              Session
            </label>
            <select
              value={sessionId || ""}
              onChange={(e) => { setSessionId(Number(e.target.value)); setTermId(0); }}
              className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
            >
              <option value="">Select Session</option>
              {sessions?.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
              Term
            </label>
            <select
              value={termId || ""}
              onChange={(e) => setTermId(Number(e.target.value))}
              disabled={!sessionId}
              className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)] disabled:opacity-50"
            >
              <option value="">Select Term</option>
              {terms?.map((t) => (
                <option key={t.id} value={t.id}>{t.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
              Class
            </label>
            <select
              value={classLevel}
              onChange={(e) => { setClassLevel(e.target.value); setSubjectId(0); }}
              className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
            >
              <option value="">Select Class</option>
              {CLASS_OPTIONS.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
              Subject
            </label>
            <select
              value={subjectId || ""}
              onChange={(e) => setSubjectId(Number(e.target.value))}
              disabled={!classLevel}
              className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)] disabled:opacity-50"
            >
              <option value="">Select Subject</option>
              {subjectsData?.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Score Entry Table */}
      {canLoadStudents && (
        <div className="bg-white rounded-lg border border-[var(--border-color)] shadow-sm overflow-hidden">
          {loadingScores ? (
            <div className="flex items-center justify-center h-48">
              <Loader2 className="w-6 h-6 animate-spin text-[var(--accent-color)]" />
            </div>
          ) : scoreListData?.students.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-48 text-[var(--text-muted)]">
              <p className="text-sm">No students found in this class.</p>
              <p className="text-xs mt-1">Add students first in the Students page.</p>
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[var(--border-color)] bg-[var(--surface-secondary)]">
                      <th className="text-left px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] w-12">
                        S/N
                      </th>
                      <th className="text-left px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                        Student Name
                      </th>
                      <th className="text-center px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] w-28">
                        Assignment
                      </th>
                      <th className="text-center px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] w-28">
                        Test
                      </th>
                      <th className="text-center px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] w-28">
                        Exam
                      </th>
                      <th className="text-center px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] w-24">
                        Total
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {scoreListData?.students.map((student, index) => (
                      <tr
                        key={student.id}
                        className="border-b border-[var(--border-subtle)] hover:bg-[var(--surface-secondary)]"
                      >
                        <td className="px-4 py-2.5 text-sm text-[var(--text-muted)]">
                          {index + 1}
                        </td>
                        <td className="px-4 py-2.5 text-sm font-medium text-[var(--text-primary)]">
                          {student.surname} {student.firstName}
                        </td>
                        <td className="px-4 py-2.5">
                          <input
                            type="text"
                            inputMode="decimal"
                            value={scoreData[student.id]?.assignment ?? ""}
                            onChange={(e) => updateScore(student.id, "assignment", e.target.value)}
                            className="w-20 h-8 px-2 text-center text-sm border-b-2 border-[var(--border-color)] bg-transparent focus:outline-none focus:border-[var(--accent-color)] transition-colors"
                            placeholder="0"
                          />
                        </td>
                        <td className="px-4 py-2.5">
                          <input
                            type="text"
                            inputMode="decimal"
                            value={scoreData[student.id]?.test ?? ""}
                            onChange={(e) => updateScore(student.id, "test", e.target.value)}
                            className="w-20 h-8 px-2 text-center text-sm border-b-2 border-[var(--border-color)] bg-transparent focus:outline-none focus:border-[var(--accent-color)] transition-colors"
                            placeholder="0"
                          />
                        </td>
                        <td className="px-4 py-2.5">
                          <input
                            type="text"
                            inputMode="decimal"
                            value={scoreData[student.id]?.exam ?? ""}
                            onChange={(e) => updateScore(student.id, "exam", e.target.value)}
                            className="w-20 h-8 px-2 text-center text-sm border-b-2 border-[var(--border-color)] bg-transparent focus:outline-none focus:border-[var(--accent-color)] transition-colors"
                            placeholder="0"
                          />
                        </td>
                        <td className="px-4 py-2.5 text-center">
                          <span className="inline-flex items-center justify-center min-w-[48px] px-2 py-0.5 rounded text-sm font-semibold bg-[var(--accent-light)] text-[var(--accent-dark)]">
                            {getTotal(student.id)}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="flex items-center justify-between px-4 py-3 border-t border-[var(--border-color)] bg-[var(--surface-secondary)]">
                <p className="text-xs text-[var(--text-muted)]">
                  {scoreListData?.students.length ?? 0} students
                </p>
                <button
                  onClick={handleSave}
                  disabled={saveMutation.isPending || !hasChanges}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-[var(--accent-color)] text-white text-sm font-medium hover:bg-[var(--accent-hover)] disabled:opacity-50 transition-colors"
                >
                  {saveMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4" />
                  )}
                  Save All Scores
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {!canLoadStudents && (
        <div className="bg-white rounded-lg border border-[var(--border-color)] p-12 shadow-sm text-center">
          <div className="w-16 h-16 rounded-full bg-[var(--accent-light)] flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-[var(--accent-color)]" />
          </div>
          <h3 className="text-base font-semibold text-[var(--text-primary)] mb-2">
            Select Criteria
          </h3>
          <p className="text-sm text-[var(--text-muted)] max-w-sm mx-auto">
            Choose the academic session, term, class, and subject to load the score entry form.
          </p>
        </div>
      )}
    </div>
  );
}
