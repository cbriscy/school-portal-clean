import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, X, BookOpen } from "lucide-react";

const CLASS_OPTIONS = [
  "Pre-Nursery", "Nursery 1", "Nursery 2",
  "Primary 1", "Primary 2", "Primary 3", "Primary 4", "Primary 5", "Primary 6",
  "JSS 1", "JSS 2", "JSS 3",
  "SSS 1", "SSS 2", "SSS 3",
];

export default function Subjects() {
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState<any>(null);

  const [formData, setFormData] = useState({
    name: "",
    code: "",
    assignmentMax: 10,
    testMax: 30,
    examMax: 60,
    classLevels: [] as string[],
  });

  const utils = trpc.useUtils();
  const { data: subjects, isLoading } = trpc.subject.list.useQuery();

  const createMutation = trpc.subject.create.useMutation({
    onSuccess: () => {
      utils.subject.list.invalidate();
      utils.dashboard.stats.invalidate();
      setShowAddModal(false);
      resetForm();
      toast.success("Subject created!");
    },
  });

  const updateMutation = trpc.subject.update.useMutation({
    onSuccess: () => {
      utils.subject.list.invalidate();
      setShowEditModal(false);
      toast.success("Subject updated!");
    },
  });

  const deleteMutation = trpc.subject.delete.useMutation({
    onSuccess: () => {
      utils.subject.list.invalidate();
      utils.dashboard.stats.invalidate();
      setShowDeleteConfirm(false);
      setSelectedSubject(null);
      toast.success("Subject deleted!");
    },
  });

  const resetForm = () => {
    setFormData({
      name: "",
      code: "",
      assignmentMax: 10,
      testMax: 30,
      examMax: 60,
      classLevels: [],
    });
  };

  const openEdit = async (subject: any) => {
    const detail = await utils.subject.getById.fetch({ id: subject.id });
    if (detail) {
      setSelectedSubject(detail);
      setFormData({
        name: detail.name,
        code: detail.code,
        assignmentMax: detail.assignmentMax,
        testMax: detail.testMax,
        examMax: detail.examMax,
        classLevels: detail.classLevels ?? [],
      });
      setShowEditModal(true);
    }
  };

  const toggleClassLevel = (classLevel: string) => {
    setFormData((prev) => ({
      ...prev,
      classLevels: prev.classLevels.includes(classLevel)
        ? prev.classLevels.filter((c) => c !== classLevel)
        : [...prev.classLevels, classLevel],
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.code) return;
    createMutation.mutate(formData);
  };

  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSubject) return;
    updateMutation.mutate({
      id: selectedSubject.id,
      name: formData.name,
      code: formData.code,
      assignmentMax: formData.assignmentMax,
      testMax: formData.testMax,
      examMax: formData.examMax,
      classLevels: formData.classLevels,
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-xl font-semibold text-[var(--text-primary)]">Subjects</h1>
        <button
          onClick={() => { resetForm(); setShowAddModal(true); }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-[var(--accent-color)] text-white text-sm font-medium hover:bg-[var(--accent-hover)]"
        >
          <Plus className="w-4 h-4" />
          Add Subject
        </button>
      </div>

      <div className="bg-white rounded-lg border border-[var(--border-color)] shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[var(--border-color)] bg-[var(--surface-secondary)]">
                <th className="text-left px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                  Code
                </th>
                <th className="text-left px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                  Subject Name
                </th>
                <th className="text-center px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                  Assignment
                </th>
                <th className="text-center px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                  Test
                </th>
                <th className="text-center px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                  Exam
                </th>
                <th className="text-right px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                  Action
                </th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                [...Array(5)].map((_, i) => (
                  <tr key={i} className="border-b border-[var(--border-subtle)]">
                    {[...Array(6)].map((_, j) => (
                      <td key={j} className="px-4 py-3">
                        <div className="h-4 bg-gray-200 rounded animate-pulse" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : subjects?.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-12 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <BookOpen className="w-12 h-12 text-[var(--text-muted)]" />
                      <p className="text-sm text-[var(--text-muted)]">
                        No subjects yet. Add your first subject.
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                subjects?.map((subject) => (
                  <tr
                    key={subject.id}
                    className="border-b border-[var(--border-subtle)] hover:bg-[var(--surface-secondary)]"
                  >
                    <td className="px-4 py-3 text-sm font-medium text-[var(--text-primary)]">
                      {subject.code}
                    </td>
                    <td className="px-4 py-3 text-sm text-[var(--text-secondary)]">
                      {subject.name}
                    </td>
                    <td className="px-4 py-3 text-center text-sm text-[var(--text-secondary)]">
                      {subject.assignmentMax}
                    </td>
                    <td className="px-4 py-3 text-center text-sm text-[var(--text-secondary)]">
                      {subject.testMax}
                    </td>
                    <td className="px-4 py-3 text-center text-sm text-[var(--text-secondary)]">
                      {subject.examMax}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => openEdit(subject)}
                          className="p-1.5 rounded-md hover:bg-gray-100 text-[var(--text-muted)] hover:text-[var(--info)]"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => { setSelectedSubject(subject); setShowDeleteConfirm(true); }}
                          className="p-1.5 rounded-md hover:bg-gray-100 text-[var(--text-muted)] hover:text-[var(--danger)]"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Modal */}
      {(showAddModal || showEditModal) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-4 py-3 border-b border-[var(--border-color)]">
              <h3 className="text-base font-semibold text-[var(--text-primary)]">
                {showEditModal ? "Edit Subject" : "Add Subject"}
              </h3>
              <button
                onClick={() => { setShowAddModal(false); setShowEditModal(false); }}
                className="p-1 rounded-md hover:bg-gray-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={showEditModal ? handleUpdate : handleSubmit} className="p-4 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                    Subject Name *
                  </label>
                  <input
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                    Subject Code *
                  </label>
                  <input
                    required
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                    className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                    placeholder="e.g. MATH"
                  />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                    Assignment Max
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={formData.assignmentMax}
                    onChange={(e) => setFormData({ ...formData, assignmentMax: Number(e.target.value) })}
                    className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                    Test Max
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={formData.testMax}
                    onChange={(e) => setFormData({ ...formData, testMax: Number(e.target.value) })}
                    className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                    Exam Max
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={formData.examMax}
                    onChange={(e) => setFormData({ ...formData, examMax: Number(e.target.value) })}
                    className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-[var(--text-primary)] mb-2">
                  Classes Offering This Subject
                </label>
                <div className="grid grid-cols-3 gap-2 max-h-48 overflow-y-auto p-2 border border-[var(--border-color)] rounded-md">
                  {CLASS_OPTIONS.map((c) => (
                    <label key={c} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.classLevels.includes(c)}
                        onChange={() => toggleClassLevel(c)}
                        className="w-4 h-4 rounded border-[var(--border-color)] text-[var(--accent-color)] focus:ring-[var(--accent-color)]"
                      />
                      <span className="text-xs text-[var(--text-secondary)]">{c}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => { setShowAddModal(false); setShowEditModal(false); }}
                  className="px-4 py-2 rounded-md border border-[var(--border-color)] text-sm font-medium text-[var(--text-secondary)] hover:bg-[var(--surface-secondary)]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  className="px-4 py-2 rounded-md bg-[var(--accent-color)] text-white text-sm font-medium hover:bg-[var(--accent-hover)] disabled:opacity-50"
                >
                  {showEditModal ? "Update" : "Save"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {showDeleteConfirm && selectedSubject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-sm p-4">
            <h3 className="text-base font-semibold text-[var(--text-primary)] mb-2">
              Delete Subject
            </h3>
            <p className="text-sm text-[var(--text-secondary)] mb-4">
              Delete <strong>{selectedSubject.name}</strong>? This cannot be undone.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => { setShowDeleteConfirm(false); setSelectedSubject(null); }}
                className="px-4 py-2 rounded-md border border-[var(--border-color)] text-sm font-medium text-[var(--text-secondary)] hover:bg-[var(--surface-secondary)]"
              >
                Cancel
              </button>
              <button
                onClick={() => deleteMutation.mutate({ id: selectedSubject.id })}
                disabled={deleteMutation.isPending}
                className="px-4 py-2 rounded-md bg-[var(--danger)] text-white text-sm font-medium hover:bg-red-700 disabled:opacity-50"
              >
                {deleteMutation.isPending ? "Deleting..." : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
