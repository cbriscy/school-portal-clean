import { Link } from "react-router";
import { ArrowLeft, GraduationCap } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[var(--canvas)] p-4">
      <div className="text-center">
        <div className="w-16 h-16 rounded-2xl bg-[var(--accent-light)] flex items-center justify-center mx-auto mb-4">
          <GraduationCap className="w-8 h-8 text-[var(--accent-color)]" />
        </div>
        <h1 className="text-4xl font-bold text-[var(--text-primary)] mb-2">404</h1>
        <p className="text-sm text-[var(--text-muted)] mb-6">
          The page you are looking for does not exist.
        </p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-[var(--accent-color)] text-white text-sm font-medium hover:bg-[var(--accent-hover)] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </Link>
      </div>
    </div>
  );
}
