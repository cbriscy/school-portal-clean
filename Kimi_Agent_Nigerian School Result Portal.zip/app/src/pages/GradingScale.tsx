import { useState, useEffect } from "react";
import { trpc } from "@/providers/trpc";
import { toast } from "sonner";
import { Save, RotateCcw, Loader2 } from "lucide-react";

export default function GradingScalePage() {
  const utils = trpc.useUtils();
  const { data: gradingScale, isLoading } = trpc.settings.getGradingScale.useQuery();

  const [editedScale, setEditedScale] = useState<typeof gradingScale>([]);
  const [hasChanges, setHasChanges] = useState(false);

  // Sync edited scale with fetched data
  useEffect(() => {
    if (gradingScale && gradingScale.length > 0) {
      setEditedScale(gradingScale);
    }
  }, [gradingScale]);

  const updateMutation = trpc.settings.updateGradingScale.useMutation({
    onSuccess: () => {
      utils.settings.getGradingScale.invalidate();
      setHasChanges(false);
      toast.success("Grading scale updated!");
    },
  });

  const resetMutation = trpc.settings.resetGradingScale.useMutation({
    onSuccess: () => {
      utils.settings.getGradingScale.invalidate();
      setHasChanges(false);
      toast.success("Grading scale reset to defaults!");
    },
  });

  const updateGrade = (id: number, field: string, value: string | number) => {
    setEditedScale((prev) =>
      (prev ?? []).map((g) =>
        g.id === id ? { ...g, [field]: value } : g
      )
    );
    setHasChanges(true);
  };

  const handleSave = () => {
    updateMutation.mutate((editedScale ?? []).map((g) => ({
      id: g.id,
      grade: g.grade,
      minScore: g.minScore,
      maxScore: g.maxScore,
      remark: g.remark,
    })));
  };

  const gradeColor = (grade: string) => {
    switch (grade) {
      case "A": return "bg-emerald-50 text-emerald-600 border-emerald-200";
      case "B": return "bg-blue-50 text-blue-600 border-blue-200";
      case "C": return "bg-sky-50 text-sky-600 border-sky-200";
      case "D": return "bg-amber-50 text-amber-600 border-amber-200";
      case "E": return "bg-orange-50 text-orange-600 border-orange-200";
      case "F": return "bg-red-50 text-red-600 border-red-200";
      default: return "bg-gray-50 text-gray-600 border-gray-200";
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-48">
        <Loader2 className="w-6 h-6 animate-spin text-[var(--accent-color)]" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold text-[var(--text-primary)]">Grading Scale</h1>
          <p className="text-sm text-[var(--text-muted)] mt-0.5">
            Configure the grading system used for result computation.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => resetMutation.mutate()}
            disabled={resetMutation.isPending}
            className="inline-flex items-center gap-2 px-3 py-2 rounded-md border border-[var(--border-color)] text-sm font-medium text-[var(--text-secondary)] hover:bg-[var(--surface-secondary)] disabled:opacity-50"
          >
            <RotateCcw className="w-4 h-4" />
            Reset
          </button>
          <button
            onClick={handleSave}
            disabled={!hasChanges || updateMutation.isPending}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-[var(--accent-color)] text-white text-sm font-medium hover:bg-[var(--accent-hover)] disabled:opacity-50"
          >
            {updateMutation.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            Save Changes
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-[var(--border-color)] shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[var(--border-color)] bg-[var(--surface-secondary)]">
                <th className="text-left px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] w-24">
                  Grade
                </th>
                <th className="text-center px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] w-32">
                  Min Score
                </th>
                <th className="text-center px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] w-32">
                  Max Score
                </th>
                <th className="text-left px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                  Remark
                </th>
              </tr>
            </thead>
            <tbody>
              {(editedScale ?? []).map((grade) => (
                <tr
                  key={grade.id}
                  className="border-b border-[var(--border-subtle)] hover:bg-[var(--surface-secondary)]"
                >
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center justify-center w-8 h-8 rounded-lg text-sm font-bold border ${gradeColor(grade.grade)}`}>
                      {grade.grade}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={grade.minScore}
                      onChange={(e) => updateGrade(grade.id, "minScore", Number(e.target.value))}
                      className="w-20 h-8 px-2 text-center text-sm border border-[var(--border-color)] rounded focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                    />
                  </td>
                  <td className="px-4 py-3">
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={grade.maxScore}
                      onChange={(e) => updateGrade(grade.id, "maxScore", Number(e.target.value))}
                      className="w-20 h-8 px-2 text-center text-sm border border-[var(--border-color)] rounded focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                    />
                  </td>
                  <td className="px-4 py-3">
                    <input
                      type="text"
                      value={grade.remark}
                      onChange={(e) => updateGrade(grade.id, "remark", e.target.value)}
                      className="w-full h-8 px-2 text-sm border border-[var(--border-color)] rounded focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Info Card */}
      <div className="bg-white rounded-lg border border-[var(--border-color)] p-4 shadow-sm">
        <h3 className="text-sm font-semibold text-[var(--text-primary)] mb-3">
          How Scores Are Computed
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
          <div className="p-3 rounded-lg bg-[var(--accent-light)]">
            <p className="font-semibold text-[var(--accent-dark)] mb-1">Assignment</p>
            <p className="text-[var(--text-secondary)]">Scores entered for class assignments and homework.</p>
          </div>
          <div className="p-3 rounded-lg bg-blue-50">
            <p className="font-semibold text-blue-700 mb-1">Test</p>
            <p className="text-[var(--text-secondary)]">Continuous assessment tests and class tests.</p>
          </div>
          <div className="p-3 rounded-lg bg-emerald-50">
            <p className="font-semibold text-emerald-700 mb-1">Exam</p>
            <p className="text-[var(--text-secondary)]">End of term examination scores.</p>
          </div>
        </div>
        <p className="text-xs text-[var(--text-muted)] mt-3">
          Total Score = Assignment + Test + Exam. The grade is then determined by the grading scale above.
        </p>
      </div>
    </div>
  );
}
