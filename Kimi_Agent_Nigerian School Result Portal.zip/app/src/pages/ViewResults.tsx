import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Loader2, FileText, Printer, Trophy } from "lucide-react";

const CLASS_OPTIONS = [
  "Pre-Nursery", "Nursery 1", "Nursery 2",
  "Primary 1", "Primary 2", "Primary 3", "Primary 4", "Primary 5", "Primary 6",
  "JSS 1", "JSS 2", "JSS 3",
  "SSS 1", "SSS 2", "SSS 3",
];

export default function ViewResults() {
  const [sessionId, setSessionId] = useState<number>(0);
  const [termId, setTermId] = useState<number>(0);
  const [classLevel, setClassLevel] = useState("");
  const [viewMode, setViewMode] = useState<"class" | "student">("class");
  const [selectedStudentId, setSelectedStudentId] = useState<number>(0);

  const { data: sessions } = trpc.session.listSessions.useQuery();
  const { data: terms } = trpc.session.listTerms.useQuery(
    sessionId ? { sessionId } : undefined,
    { enabled: sessionId > 0 }
  );

  // Class results
  const { data: classResults, isLoading: loadingClass } = trpc.score.getClassResults.useQuery(
    { sessionId, termId, classLevel },
    { enabled: viewMode === "class" && sessionId > 0 && termId > 0 && classLevel.length > 0 }
  );

  // Student result
  const { data: studentResult } = trpc.score.getStudentResult.useQuery(
    { studentId: selectedStudentId, sessionId, termId },
    { enabled: viewMode === "student" && selectedStudentId > 0 && sessionId > 0 && termId > 0 }
  );

  const canView = sessionId > 0 && termId > 0;

  const gradeColor = (grade: string | null) => {
    switch (grade) {
      case "A": return "bg-emerald-50 text-emerald-600";
      case "B": return "bg-blue-50 text-blue-600";
      case "C": return "bg-sky-50 text-sky-600";
      case "D": return "bg-amber-50 text-amber-600";
      case "E": return "bg-orange-50 text-orange-600";
      case "F": return "bg-red-50 text-red-600";
      default: return "bg-gray-50 text-gray-600";
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-xl font-semibold text-[var(--text-primary)]">View Results</h1>
        <button
          onClick={handlePrint}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-md border border-[var(--border-color)] text-sm font-medium text-[var(--text-secondary)] hover:bg-[var(--surface-secondary)] transition-colors"
        >
          <Printer className="w-4 h-4" />
          Print
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg border border-[var(--border-color)] p-4 shadow-sm">
        <div className="flex flex-col gap-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                Session
              </label>
              <select
                value={sessionId || ""}
                onChange={(e) => { setSessionId(Number(e.target.value)); setTermId(0); }}
                className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
              >
                <option value="">Select Session</option>
                {sessions?.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                Term
              </label>
              <select
                value={termId || ""}
                onChange={(e) => setTermId(Number(e.target.value))}
                disabled={!sessionId}
                className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)] disabled:opacity-50"
              >
                <option value="">Select Term</option>
                {terms?.map((t) => (
                  <option key={t.id} value={t.id}>{t.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                Class
              </label>
              <select
                value={classLevel}
                onChange={(e) => setClassLevel(e.target.value)}
                className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
              >
                <option value="">Select Class</option>
                {CLASS_OPTIONS.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-[var(--text-muted)] uppercase">View By:</span>
            <div className="flex bg-[var(--surface-secondary)] rounded-md p-0.5">
              <button
                onClick={() => setViewMode("class")}
                className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                  viewMode === "class"
                    ? "bg-white text-[var(--text-primary)] shadow-sm"
                    : "text-[var(--text-muted)]"
                }`}
              >
                Class
              </button>
              <button
                onClick={() => setViewMode("student")}
                className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                  viewMode === "student"
                    ? "bg-white text-[var(--text-primary)] shadow-sm"
                    : "text-[var(--text-muted)]"
                }`}
              >
                Individual Student
              </button>
            </div>
            {viewMode === "student" && classResults?.students && (
              <select
                value={selectedStudentId || ""}
                onChange={(e) => setSelectedStudentId(Number(e.target.value))}
                className="h-8 px-2 rounded-md border border-[var(--border-color)] text-sm ml-2"
              >
                <option value="">Select Student</option>
                {classResults.students.map((s) => (
                  <option key={s.student.id} value={s.student.id}>
                    {s.student.surname} {s.student.firstName}
                  </option>
                ))}
              </select>
            )}
          </div>
        </div>
      </div>

      {/* Class Results View */}
      {viewMode === "class" && canView && classLevel && (
        <div className="bg-white rounded-lg border border-[var(--border-color)] shadow-sm overflow-hidden">
          {loadingClass ? (
            <div className="flex items-center justify-center h-48">
              <Loader2 className="w-6 h-6 animate-spin text-[var(--accent-color)]" />
            </div>
          ) : !classResults || classResults.students.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-48 text-[var(--text-muted)]">
              <FileText className="w-12 h-12 mb-3" />
              <p className="text-sm">No results found for this class.</p>
              <p className="text-xs mt-1">Enter scores first to generate results.</p>
            </div>
          ) : (
            <>
              <div className="px-4 py-3 border-b border-[var(--border-color)] bg-[var(--surface-secondary)]">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-semibold text-[var(--text-primary)]">
                      {classLevel} Results
                    </h3>
                    <p className="text-xs text-[var(--text-muted)]">
                      {classResults.totalStudents} students | {classResults.subjects.length} subjects
                    </p>
                  </div>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[var(--border-color)] bg-[var(--surface-secondary)]">
                      <th className="text-center px-3 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] w-12">
                        Rank
                      </th>
                      <th className="text-left px-3 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                        Name
                      </th>
                      {classResults.subjects.map((sub) => (
                        <th
                          key={sub.id}
                          className="text-center px-2 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]"
                        >
                          {sub.code}
                        </th>
                      ))}
                      <th className="text-center px-3 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                        Avg
                      </th>
                      <th className="text-center px-3 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                        Grade
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {classResults.students.map((result) => (
                      <tr
                        key={result.student.id}
                        className="border-b border-[var(--border-subtle)] hover:bg-[var(--surface-secondary)]"
                      >
                        <td className="px-3 py-2.5 text-center">
                          {result.rank <= 3 ? (
                            <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-[var(--accent-light)] text-[var(--accent-dark)] text-xs font-bold">
                              {result.rank}
                            </span>
                          ) : (
                            <span className="text-xs text-[var(--text-muted)]">{result.rank}</span>
                          )}
                        </td>
                        <td className="px-3 py-2.5 text-sm font-medium text-[var(--text-primary)] whitespace-nowrap">
                          {result.student.surname} {result.student.firstName}
                        </td>
                        {classResults.subjects.map((sub) => {
                          const score = result.scores.find((s) => s.subjectId === sub.id);
                          return (
                            <td key={sub.id} className="px-2 py-2.5 text-center">
                              <span className={`inline-flex px-1.5 py-0.5 rounded text-xs font-medium ${gradeColor(score?.grade ?? null)}`}>
                                {score?.totalScore ?? "-"}
                              </span>
                            </td>
                          );
                        })}
                        <td className="px-3 py-2.5 text-center">
                          <span className="text-sm font-semibold text-[var(--text-primary)]">
                            {result.averageScore}
                          </span>
                        </td>
                        <td className="px-3 py-2.5 text-center">
                          <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-bold ${gradeColor(result.grade)}`}>
                            {result.grade}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      )}

      {/* Individual Student Result */}
      {viewMode === "student" && studentResult && (
        <div className="bg-white rounded-lg border border-[var(--border-color)] shadow-sm overflow-hidden print:shadow-none">
          {/* Student Header */}
          <div className="px-6 py-5 border-b border-[var(--border-color)]">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-[var(--accent-light)] flex items-center justify-center">
                <span className="text-xl font-bold text-[var(--accent-dark)]">
                  {studentResult.student.firstName?.[0]}{studentResult.student.surname?.[0]}
                </span>
              </div>
              <div>
                <h3 className="text-lg font-bold text-[var(--text-primary)]">
                  {studentResult.student.surname} {studentResult.student.firstName}
                </h3>
                <div className="flex flex-wrap gap-x-4 gap-y-1 mt-1">
                  <span className="text-xs text-[var(--text-muted)]">
                    <strong className="text-[var(--text-secondary)]">Class:</strong> {studentResult.student.currentClass}
                  </span>
                  <span className="text-xs text-[var(--text-muted)]">
                    <strong className="text-[var(--text-secondary)]">Admission:</strong> {studentResult.student.admissionNo}
                  </span>
                </div>
              </div>
              <div className="ml-auto text-right">
                <div className="flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-[var(--accent-color)]" />
                  <span className="text-2xl font-bold text-[var(--text-primary)]">
                    {studentResult.averageScore}
                  </span>
                </div>
                <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-bold ${gradeColor(studentResult.overallGrade)}`}>
                  {studentResult.overallGrade} — {studentResult.overallRemark}
                </span>
              </div>
            </div>
          </div>

          {/* Subject Scores */}
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[var(--border-color)] bg-[var(--surface-secondary)]">
                  <th className="text-left px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                    Subject
                  </th>
                  <th className="text-center px-3 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                    Assignment
                  </th>
                  <th className="text-center px-3 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                    Test
                  </th>
                  <th className="text-center px-3 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                    Exam
                  </th>
                  <th className="text-center px-3 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                    Total
                  </th>
                  <th className="text-center px-3 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                    Grade
                  </th>
                  <th className="text-left px-3 py-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                    Remark
                  </th>
                </tr>
              </thead>
              <tbody>
                {studentResult.scores.map((score) => (
                  <tr
                    key={score.id}
                    className="border-b border-[var(--border-subtle)] hover:bg-[var(--surface-secondary)]"
                  >
                    <td className="px-4 py-2.5 text-sm font-medium text-[var(--text-primary)]">
                      {score.subjectName}
                    </td>
                    <td className="px-3 py-2.5 text-center text-sm text-[var(--text-secondary)]">
                      {score.assignmentScore ?? 0}
                      <span className="text-xs text-[var(--text-muted)]">/{score.assignmentMax}</span>
                    </td>
                    <td className="px-3 py-2.5 text-center text-sm text-[var(--text-secondary)]">
                      {score.testScore ?? 0}
                      <span className="text-xs text-[var(--text-muted)]">/{score.testMax}</span>
                    </td>
                    <td className="px-3 py-2.5 text-center text-sm text-[var(--text-secondary)]">
                      {score.examScore ?? 0}
                      <span className="text-xs text-[var(--text-muted)]">/{score.examMax}</span>
                    </td>
                    <td className="px-3 py-2.5 text-center">
                      <span className="text-sm font-semibold text-[var(--text-primary)]">
                        {score.totalScore ?? 0}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 text-center">
                      <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-bold ${gradeColor(score.grade)}`}>
                        {score.grade ?? "-"}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 text-sm text-[var(--text-secondary)]">
                      {score.remark ?? "-"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Summary */}
          <div className="px-6 py-4 border-t border-[var(--border-color)] bg-[var(--surface-secondary)]">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="text-center">
                <p className="text-[11px] uppercase tracking-wider text-[var(--text-muted)]">Total Subjects</p>
                <p className="text-lg font-bold text-[var(--text-primary)]">{studentResult.totalSubjects}</p>
              </div>
              <div className="text-center">
                <p className="text-[11px] uppercase tracking-wider text-[var(--text-muted)]">Total Score</p>
                <p className="text-lg font-bold text-[var(--text-primary)]">{studentResult.totalScore}</p>
              </div>
              <div className="text-center">
                <p className="text-[11px] uppercase tracking-wider text-[var(--text-muted)]">Average</p>
                <p className="text-lg font-bold text-[var(--text-primary)]">{studentResult.averageScore}</p>
              </div>
              <div className="text-center">
                <p className="text-[11px] uppercase tracking-wider text-[var(--text-muted)]">Overall</p>
                <p className="text-lg font-bold text-[var(--accent-color)]">{studentResult.overallGrade}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {!canView && (
        <div className="bg-white rounded-lg border border-[var(--border-color)] p-12 shadow-sm text-center">
          <FileText className="w-12 h-12 text-[var(--text-muted)] mx-auto mb-3" />
          <p className="text-sm text-[var(--text-muted)]">
            Select session and term to view results.
          </p>
        </div>
      )}
    </div>
  );
}
