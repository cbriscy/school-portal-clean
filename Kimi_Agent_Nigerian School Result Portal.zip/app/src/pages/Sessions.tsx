import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { toast } from "sonner";
import { Calendar, CheckCircle2, Clock, Lock, Plus, X } from "lucide-react";

export default function SessionsPage() {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newSessionName, setNewSessionName] = useState("");

  const utils = trpc.useUtils();
  const { data: sessions, isLoading } = trpc.session.listSessions.useQuery();

  const setActiveMutation = trpc.session.setActiveSession.useMutation({
    onSuccess: () => {
      utils.session.listSessions.invalidate();
      toast.success("Session activated!");
    },
  });

  const setActiveTermMutation = trpc.session.setActiveTerm.useMutation({
    onSuccess: () => {
      utils.session.listTerms.invalidate();
      utils.session.listSessions.invalidate();
      toast.success("Term activated!");
    },
  });

  const closeTermMutation = trpc.session.closeTerm.useMutation({
    onSuccess: () => {
      utils.session.listTerms.invalidate();
      toast.success("Term closed!");
    },
  });

  const createMutation = trpc.session.createSession.useMutation({
    onSuccess: () => {
      utils.session.listSessions.invalidate();
      setShowAddModal(false);
      setNewSessionName("");
      toast.success("Session created!");
    },
  });

  const getTermBadge = (term: any) => {
    if (term.isClosed) {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600">
          <Lock className="w-3 h-3" />
          Closed
        </span>
      );
    }
    if (term.isActive) {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium bg-emerald-50 text-emerald-600">
          <CheckCircle2 className="w-3 h-3" />
          Active
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-500">
        <Clock className="w-3 h-3" />
        Upcoming
      </span>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold text-[var(--text-primary)]">Academic Sessions</h1>
          <p className="text-sm text-[var(--text-muted)] mt-0.5">
            Manage academic sessions and terms.
          </p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-[var(--accent-color)] text-white text-sm font-medium hover:bg-[var(--accent-hover)]"
        >
          <Plus className="w-4 h-4" />
          New Session
        </button>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center h-48">
          <div className="w-6 h-6 border-2 border-[var(--accent-color)] border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (
        <div className="space-y-4">
          {sessions?.map((session) => (
            <SessionCard
              key={session.id}
              session={session}
              onActivate={() => setActiveMutation.mutate({ id: session.id })}
              onActivateTerm={(termId) => setActiveTermMutation.mutate({ id: termId })}
              onCloseTerm={(termId) => closeTermMutation.mutate({ id: termId })}
              getTermBadge={getTermBadge}
              isActivating={setActiveMutation.isPending}
            />
          ))}
        </div>
      )}

      {/* Add Session Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-sm">
            <div className="flex items-center justify-between px-4 py-3 border-b border-[var(--border-color)]">
              <h3 className="text-base font-semibold text-[var(--text-primary)]">
                New Academic Session
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-md hover:bg-gray-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-4">
              <div>
                <label className="block text-xs font-medium text-[var(--text-primary)] mb-1">
                  Session Name *
                </label>
                <input
                  value={newSessionName}
                  onChange={(e) => setNewSessionName(e.target.value)}
                  placeholder="e.g. 2025/2026"
                  className="w-full h-10 px-3 rounded-md border border-[var(--border-color)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-light)] focus:border-[var(--accent-color)]"
                />
              </div>
              <div className="flex justify-end gap-3">
                <button
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-md border border-[var(--border-color)] text-sm font-medium text-[var(--text-secondary)] hover:bg-[var(--surface-secondary)]"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (newSessionName.trim()) {
                      createMutation.mutate({ name: newSessionName.trim() });
                    }
                  }}
                  disabled={createMutation.isPending || !newSessionName.trim()}
                  className="px-4 py-2 rounded-md bg-[var(--accent-color)] text-white text-sm font-medium hover:bg-[var(--accent-hover)] disabled:opacity-50"
                >
                  {createMutation.isPending ? "Creating..." : "Create"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function SessionCard({
  session,
  onActivate,
  onActivateTerm,
  onCloseTerm,
  getTermBadge,
  isActivating,
}: {
  session: any;
  onActivate: () => void;
  onActivateTerm: (termId: number) => void;
  onCloseTerm: (termId: number) => void;
  getTermBadge: (term: any) => React.ReactNode;
  isActivating: boolean;
}) {
  const { data: terms } = trpc.session.listTerms.useQuery(
    { sessionId: session.id }
  );

  return (
    <div className="bg-white rounded-lg border border-[var(--border-color)] shadow-sm p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-[var(--accent-light)] flex items-center justify-center">
            <Calendar className="w-5 h-5 text-[var(--accent-color)]" />
          </div>
          <div>
            <h3 className="text-base font-semibold text-[var(--text-primary)]">
              {session.name} Session
            </h3>
            {session.isActive && (
              <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-600">
                <CheckCircle2 className="w-3 h-3" />
                Currently Active
              </span>
            )}
          </div>
        </div>
        {!session.isActive && (
          <button
            onClick={onActivate}
            disabled={isActivating}
            className="px-3 py-1.5 rounded-md text-xs font-medium bg-[var(--accent-light)] text-[var(--accent-dark)] hover:bg-[var(--accent-color)] hover:text-white transition-colors disabled:opacity-50"
          >
            Set as Active
          </button>
        )}
      </div>

      {/* Terms */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {terms?.map((term) => (
          <div
            key={term.id}
            className={`p-3 rounded-lg border ${
              term.isActive
                ? "border-emerald-200 bg-emerald-50"
                : term.isClosed
                ? "border-gray-200 bg-gray-50"
                : "border-[var(--border-color)] bg-white"
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-[var(--text-primary)]">
                {term.name}
              </span>
              {getTermBadge(term)}
            </div>
            {term.startDate && term.endDate && (
              <p className="text-xs text-[var(--text-muted)] mb-2">
                {new Date(term.startDate).toLocaleDateString()} —{" "}
                {new Date(term.endDate).toLocaleDateString()}
              </p>
            )}
            {!term.isClosed && !term.isActive && (
              <button
                onClick={() => onActivateTerm(term.id)}
                className="w-full mt-1 px-2 py-1 rounded text-xs font-medium bg-white border border-[var(--border-color)] text-[var(--text-secondary)] hover:bg-[var(--surface-secondary)]"
              >
                Activate
              </button>
            )}
            {term.isActive && (
              <button
                onClick={() => onCloseTerm(term.id)}
                className="w-full mt-1 px-2 py-1 rounded text-xs font-medium bg-white border border-red-200 text-red-600 hover:bg-red-50"
              >
                Close Term
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
