import { Routes, Route } from "react-router";
import { Toaster } from "sonner";
import AppLayout from "./components/layout/AppLayout";
import Dashboard from "./pages/Dashboard";
import Students from "./pages/Students";
import EnterScores from "./pages/EnterScores";
import ViewResults from "./pages/ViewResults";
import Subjects from "./pages/Subjects";
import GradingScalePage from "./pages/GradingScale";
import SessionsPage from "./pages/Sessions";
import SettingsPage from "./pages/SettingsPage";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";

function AppLayoutWrapper({ children }: { children: React.ReactNode }) {
  return <AppLayout>{children}</AppLayout>;
}

export default function App() {
  return (
    <>
      <Toaster position="top-right" richColors />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/"
          element={
            <AppLayoutWrapper>
              <Dashboard />
            </AppLayoutWrapper>
          }
        />
        <Route
          path="/students"
          element={
            <AppLayoutWrapper>
              <Students />
            </AppLayoutWrapper>
          }
        />
        <Route
          path="/scores"
          element={
            <AppLayoutWrapper>
              <EnterScores />
            </AppLayoutWrapper>
          }
        />
        <Route
          path="/results"
          element={
            <AppLayoutWrapper>
              <ViewResults />
            </AppLayoutWrapper>
          }
        />
        <Route
          path="/subjects"
          element={
            <AppLayoutWrapper>
              <Subjects />
            </AppLayoutWrapper>
          }
        />
        <Route
          path="/grading"
          element={
            <AppLayoutWrapper>
              <GradingScalePage />
            </AppLayoutWrapper>
          }
        />
        <Route
          path="/sessions"
          element={
            <AppLayoutWrapper>
              <SessionsPage />
            </AppLayoutWrapper>
          }
        />
        <Route
          path="/settings"
          element={
            <AppLayoutWrapper>
              <SettingsPage />
            </AppLayoutWrapper>
          }
        />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
}
