import { z } from "zod";
import { eq, count } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { subjects, subjectClasses } from "@db/schema";

export const subjectRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    const data = await db.select().from(subjects).orderBy(subjects.name);
    return data;
  }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const subject = await db
        .select()
        .from(subjects)
        .where(eq(subjects.id, input.id))
        .limit(1);

      if (!subject[0]) return null;

      const classes = await db
        .select()
        .from(subjectClasses)
        .where(eq(subjectClasses.subjectId, input.id));

      return {
        ...subject[0],
        classLevels: classes.map((c) => c.classLevel),
      };
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1),
        code: z.string().min(1),
        assignmentMax: z.number().min(1).max(100).default(10),
        testMax: z.number().min(1).max(100).default(30),
        examMax: z.number().min(1).max(100).default(60),
        classLevels: z.array(z.string()),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const result = await db.insert(subjects).values({
        name: input.name,
        code: input.code,
        assignmentMax: input.assignmentMax,
        testMax: input.testMax,
        examMax: input.examMax,
      });

      const subjectId = Number(result[0].insertId);

      // Insert class mappings
      if (input.classLevels.length > 0) {
        await db.insert(subjectClasses).values(
          input.classLevels.map((classLevel) => ({
            subjectId,
            classLevel: classLevel as any,
          }))
        );
      }

      return { id: subjectId };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        code: z.string().min(1).optional(),
        assignmentMax: z.number().min(1).max(100).optional(),
        testMax: z.number().min(1).max(100).optional(),
        examMax: z.number().min(1).max(100).optional(),
        classLevels: z.array(z.string()).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, classLevels, ...updateData } = input;

      const cleanData = Object.fromEntries(
        Object.entries(updateData).filter(([, v]) => v !== undefined)
      );

      if (Object.keys(cleanData).length > 0) {
        await db.update(subjects).set(cleanData).where(eq(subjects.id, id));
      }

      if (classLevels !== undefined) {
        // Delete existing mappings
        await db.delete(subjectClasses).where(eq(subjectClasses.subjectId, id));
        // Insert new mappings
        if (classLevels.length > 0) {
          await db.insert(subjectClasses).values(
            classLevels.map((classLevel) => ({
              subjectId: id,
              classLevel: classLevel as any,
            }))
          );
        }
      }

      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(subjectClasses).where(eq(subjectClasses.subjectId, input.id));
      await db.delete(subjects).where(eq(subjects.id, input.id));
      return { success: true };
    }),

  count: publicQuery.query(async () => {
    const db = getDb();
    const result = await db.select({ count: count() }).from(subjects);
    return result[0].count;
  }),

  // Get subjects available for a specific class
  getByClass: publicQuery
    .input(z.object({ classLevel: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const mappings = await db
        .select()
        .from(subjectClasses)
        .where(eq(subjectClasses.classLevel, input.classLevel as any));

      if (mappings.length === 0) return [];

      const subjectIds = mappings.map((m) => m.subjectId);
      const data = await db
        .select()
        .from(subjects)
        .where(
          subjectIds.length === 1
            ? eq(subjects.id, subjectIds[0])
            : undefined
        );

      // If multiple IDs, we need to filter in memory since Drizzle MySQL
      // doesn't support IN clause easily with the query builder
      if (subjectIds.length > 1) {
        return data.filter((s) => subjectIds.includes(s.id));
      }
      return data;
    }),
});
