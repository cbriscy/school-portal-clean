import { authRouter } from "./auth-router";
import { studentRouter } from "./student-router";
import { subjectRouter } from "./subject-router";
import { scoreRouter } from "./score-router";
import { sessionRouter } from "./session-router";
import { settingsRouter } from "./settings-router";
import { dashboardRouter } from "./dashboard-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  student: studentRouter,
  subject: subjectRouter,
  score: scoreRouter,
  session: sessionRouter,
  settings: settingsRouter,
  dashboard: dashboardRouter,
});

export type AppRouter = typeof appRouter;
