import { z } from "zod";
import { eq, desc } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { academicSessions, terms } from "@db/schema";

export const sessionRouter = createRouter({
  // Academic Sessions
  listSessions: publicQuery.query(async () => {
    const db = getDb();
    const sessions = await db
      .select()
      .from(academicSessions)
      .orderBy(desc(academicSessions.name));
    return sessions;
  }),

  getActiveSession: publicQuery.query(async () => {
    const db = getDb();
    const session = await db
      .select()
      .from(academicSessions)
      .where(eq(academicSessions.isActive, true))
      .limit(1);
    return session[0] ?? null;
  }),

  createSession: publicQuery
    .input(
      z.object({
        name: z.string().min(1),
        startDate: z.string().optional(),
        endDate: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const values: Record<string, unknown> = {
        name: input.name,
        isActive: false,
      };
      if (input.startDate) values.startDate = new Date(input.startDate);
      if (input.endDate) values.endDate = new Date(input.endDate);
      const result = await db.insert(academicSessions).values(values as any);
      return { id: Number(result[0].insertId) };
    }),

  setActiveSession: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      // Deactivate all
      await db
        .update(academicSessions)
        .set({ isActive: false });
      // Activate selected
      await db
        .update(academicSessions)
        .set({ isActive: true })
        .where(eq(academicSessions.id, input.id));
      return { success: true };
    }),

  // Terms
  listTerms: publicQuery
    .input(z.object({ sessionId: z.number() }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      if (input?.sessionId) {
        return db
          .select()
          .from(terms)
          .where(eq(terms.sessionId, input.sessionId))
          .orderBy(terms.name);
      }
      return db.select().from(terms).orderBy(terms.name);
    }),

  getActiveTerm: publicQuery.query(async () => {
    const db = getDb();
    const term = await db
      .select()
      .from(terms)
      .where(eq(terms.isActive, true))
      .limit(1);
    return term[0] ?? null;
  }),

  setActiveTerm: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      // Deactivate all terms in the same session
      const term = await db
        .select()
        .from(terms)
        .where(eq(terms.id, input.id))
        .limit(1);

      if (term[0]) {
        await db
          .update(terms)
          .set({ isActive: false })
          .where(eq(terms.sessionId, term[0].sessionId));
      }

      // Activate selected
      await db
        .update(terms)
        .set({ isActive: true, isClosed: false })
        .where(eq(terms.id, input.id));

      return { success: true };
    }),

  closeTerm: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(terms)
        .set({ isClosed: true, isActive: false })
        .where(eq(terms.id, input.id));
      return { success: true };
    }),
});
