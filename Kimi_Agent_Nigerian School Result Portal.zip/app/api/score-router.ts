import { z } from "zod";
import { eq, and, count, desc } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { scores, students, subjects, gradingScale, subjectClasses } from "@db/schema";

export const scoreRouter = createRouter({
  // Get scores for a class/subject/session/term
  getByClassSubject: publicQuery
    .input(
      z.object({
        sessionId: z.number(),
        termId: z.number(),
        classLevel: z.string(),
        subjectId: z.number(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();

      // Get students in this class
      const classStudents = await db
        .select()
        .from(students)
        .where(
          and(
            eq(students.currentClass, input.classLevel as any),
            eq(students.status, "Active")
          )
        )
        .orderBy(students.surname);

      if (classStudents.length === 0) {
        return { students: [], scores: [] };
      }

      // Get existing scores
      const existingScores = await db
        .select()
        .from(scores)
        .where(
          and(
            eq(scores.sessionId, input.sessionId),
            eq(scores.termId, input.termId),
            eq(scores.subjectId, input.subjectId)
          )
        );

      return {
        students: classStudents,
        scores: existingScores,
      };
    }),

  // Save or update scores
  saveScores: publicQuery
    .input(
      z.object({
        sessionId: z.number(),
        termId: z.number(),
        subjectId: z.number(),
        scores: z.array(
          z.object({
            studentId: z.number(),
            assignmentScore: z.number().min(0).max(100),
            testScore: z.number().min(0).max(100),
            examScore: z.number().min(0).max(100),
          })
        ),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Get subject to know max scores
      const subject = await db
        .select()
        .from(subjects)
        .where(eq(subjects.id, input.subjectId))
        .limit(1);

      const sub = subject[0];
      if (!sub) throw new Error("Subject not found");

      // Get grading scale
      const grading = await db.select().from(gradingScale);

      for (const scoreData of input.scores) {
        // Validate against max scores
        const assignment = Math.min(scoreData.assignmentScore, sub.assignmentMax);
        const test = Math.min(scoreData.testScore, sub.testMax);
        const exam = Math.min(scoreData.examScore, sub.examMax);
        const total = assignment + test + exam;

        // Determine grade
        const gradeEntry = grading.find(
          (g) => total >= g.minScore && total <= g.maxScore
        );

        const existing = await db
          .select()
          .from(scores)
          .where(
            and(
              eq(scores.studentId, scoreData.studentId),
              eq(scores.subjectId, input.subjectId),
              eq(scores.sessionId, input.sessionId),
              eq(scores.termId, input.termId)
            )
          )
          .limit(1);

        if (existing[0]) {
          await db
            .update(scores)
            .set({
              assignmentScore: String(assignment),
              testScore: String(test),
              examScore: String(exam),
              totalScore: String(total),
              grade: gradeEntry?.grade ?? null,
              remark: gradeEntry?.remark ?? null,
            })
            .where(eq(scores.id, existing[0].id));
        } else {
          await db.insert(scores).values({
            studentId: scoreData.studentId,
            subjectId: input.subjectId,
            sessionId: input.sessionId,
            termId: input.termId,
            assignmentScore: String(assignment),
            testScore: String(test),
            examScore: String(exam),
            totalScore: String(total),
            grade: gradeEntry?.grade ?? null,
            remark: gradeEntry?.remark ?? null,
          });
        }
      }

      return { success: true, count: input.scores.length };
    }),

  // Get results for a student
  getStudentResult: publicQuery
    .input(
      z.object({
        studentId: z.number(),
        sessionId: z.number(),
        termId: z.number(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();

      const student = await db
        .select()
        .from(students)
        .where(eq(students.id, input.studentId))
        .limit(1);

      if (!student[0]) return null;

      const studentScores = await db
        .select({
          score: scores,
          subject: subjects,
        })
        .from(scores)
        .innerJoin(subjects, eq(scores.subjectId, subjects.id))
        .where(
          and(
            eq(scores.studentId, input.studentId),
            eq(scores.sessionId, input.sessionId),
            eq(scores.termId, input.termId)
          )
        );

      // Calculate totals
      const totalScore = studentScores.reduce(
        (sum, s) => sum + Number(s.score.totalScore ?? 0),
        0
      );
      const avgScore = studentScores.length > 0 ? totalScore / studentScores.length : 0;

      // Get overall grade
      const grading = await db.select().from(gradingScale);
      const overallGrade = grading.find(
        (g) => avgScore >= g.minScore && avgScore <= g.maxScore
      );

      return {
        student: student[0],
        scores: studentScores.map((s) => ({
          ...s.score,
          subjectName: s.subject.name,
          subjectCode: s.subject.code,
          assignmentMax: s.subject.assignmentMax,
          testMax: s.subject.testMax,
          examMax: s.subject.examMax,
        })),
        totalSubjects: studentScores.length,
        totalScore: Math.round(totalScore * 100) / 100,
        averageScore: Math.round(avgScore * 100) / 100,
        overallGrade: overallGrade?.grade ?? "N/A",
        overallRemark: overallGrade?.remark ?? "N/A",
      };
    }),

  // Get class results
  getClassResults: publicQuery
    .input(
      z.object({
        sessionId: z.number(),
        termId: z.number(),
        classLevel: z.string(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();

      // Get students in class
      const classStudents = await db
        .select()
        .from(students)
        .where(
          and(
            eq(students.currentClass, input.classLevel as any),
            eq(students.status, "Active")
          )
        )
        .orderBy(students.surname);

      // Get subjects for this class
      const subjectMappings = await db
        .select()
        .from(subjectClasses)
        .where(eq(subjectClasses.classLevel, input.classLevel as any));

      const subjectList: typeof subjects.$inferSelect[] = [];
      for (const mapping of subjectMappings) {
        const sub = await db
          .select()
          .from(subjects)
          .where(eq(subjects.id, mapping.subjectId))
          .limit(1);
        if (sub[0]) subjectList.push(sub[0]);
      }

      // Get grading scale
      const grading = await db.select().from(gradingScale);

      // For each student, get their scores
      const results = [];
      for (const student of classStudents) {
        const studentScores = await db
          .select()
          .from(scores)
          .where(
            and(
              eq(scores.studentId, student.id),
              eq(scores.sessionId, input.sessionId),
              eq(scores.termId, input.termId)
            )
          );

        const totalScore = studentScores.reduce(
          (sum, s) => sum + Number(s.totalScore ?? 0),
          0
        );
        const avgScore =
          studentScores.length > 0 ? totalScore / studentScores.length : 0;
        const grade = grading.find(
          (g) => avgScore >= g.minScore && avgScore <= g.maxScore
        );

        results.push({
          student,
          scores: studentScores,
          totalScore: Math.round(totalScore * 100) / 100,
          averageScore: Math.round(avgScore * 100) / 100,
          grade: grade?.grade ?? "N/A",
          remark: grade?.remark ?? "N/A",
          subjectsEntered: studentScores.length,
          totalSubjects: subjectList.length,
        });
      }

      // Sort by average score (descending) and assign ranks
      results.sort((a, b) => b.averageScore - a.averageScore);
      const rankedResults = results.map((r, i) => ({
        ...r,
        rank: i + 1,
      }));

      return {
        students: rankedResults,
        subjects: subjectList,
        totalStudents: classStudents.length,
      };
    }),

  // Get recent score entries
  getRecent: publicQuery
    .input(z.object({ limit: z.number().default(10) }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const limit = input?.limit ?? 10;

      const recentScores = await db
        .select({
          score: scores,
          student: students,
          subject: subjects,
        })
        .from(scores)
        .innerJoin(students, eq(scores.studentId, students.id))
        .innerJoin(subjects, eq(scores.subjectId, subjects.id))
        .orderBy(desc(scores.updatedAt))
        .limit(limit);

      return recentScores.map((s) => ({
        id: s.score.id,
        studentName: `${s.student.surname} ${s.student.firstName}`,
        subjectName: s.subject.name,
        assignmentScore: s.score.assignmentScore,
        testScore: s.score.testScore,
        examScore: s.score.examScore,
        totalScore: s.score.totalScore,
        grade: s.score.grade,
        updatedAt: s.score.updatedAt,
      }));
    }),

  // Get completion stats
  getCompletionStats: publicQuery
    .input(
      z.object({
        sessionId: z.number(),
        termId: z.number(),
        classLevel: z.string(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();

      const classStudents = await db
        .select({ count: count() })
        .from(students)
        .where(
          and(
            eq(students.currentClass, input.classLevel as any),
            eq(students.status, "Active")
          )
        );

      const subjectMappings = await db
        .select()
        .from(subjectClasses)
        .where(eq(subjectClasses.classLevel, input.classLevel as any));

      const totalExpected =
        classStudents[0].count * subjectMappings.length;

      const actualScores = await db
        .select({ count: count() })
        .from(scores)
        .where(
          and(
            eq(scores.sessionId, input.sessionId),
            eq(scores.termId, input.termId)
          )
        );

      return {
        totalStudents: classStudents[0].count,
        totalSubjects: subjectMappings.length,
        totalExpected,
        actualEntered: actualScores[0].count,
        percentage:
          totalExpected > 0
            ? Math.round((actualScores[0].count / totalExpected) * 100)
            : 0,
      };
    }),
});
