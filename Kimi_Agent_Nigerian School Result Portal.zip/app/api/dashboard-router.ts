import { count, avg, eq, and, sql } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  students,
  subjects,
  scores,
  academicSessions,
  terms,
} from "@db/schema";

export const dashboardRouter = createRouter({
  stats: publicQuery.query(async () => {
    const db = getDb();

    const [
      studentCount,
      subjectCount,
      scoreCount,
      sessionData,
      termData,
    ] = await Promise.all([
      db
        .select({ count: count() })
        .from(students)
        .where(eq(students.status, "Active")),
      db.select({ count: count() }).from(subjects),
      db.select({ count: count() }).from(scores),
      db
        .select()
        .from(academicSessions)
        .where(eq(academicSessions.isActive, true))
        .limit(1),
      db
        .select()
        .from(terms)
        .where(eq(terms.isActive, true))
        .limit(1),
    ]);

    // Get class distribution
    const classDistribution = await db
      .select({
        class: students.currentClass,
        count: count(),
      })
      .from(students)
      .where(eq(students.status, "Active"))
      .groupBy(students.currentClass);

    // Get recent score entries
    const recentScores = await db
      .select({
        score: scores,
        student: students,
        subject: subjects,
      })
      .from(scores)
      .innerJoin(students, eq(scores.studentId, students.id))
      .innerJoin(subjects, eq(scores.subjectId, subjects.id))
      .orderBy(sql`${scores.updatedAt} DESC`)
      .limit(8);

    // Get average scores per class
    const classAverages = await db
      .select({
        class: students.currentClass,
        avgScore: avg(scores.totalScore),
      })
      .from(scores)
      .innerJoin(students, eq(scores.studentId, students.id))
      .groupBy(students.currentClass);

    // Get students with incomplete results
    // (students who don't have scores for all subjects in their class)
    const incompleteStudents = await db
      .select()
      .from(students)
      .where(
        and(
          eq(students.status, "Active"),
          sql`${students.id} NOT IN (SELECT DISTINCT ${scores.studentId} FROM ${scores})`
        )
      )
      .limit(10);

    return {
      totalStudents: studentCount[0].count,
      totalSubjects: subjectCount[0].count,
      totalScoresEntered: scoreCount[0].count,
      activeSession: sessionData[0] ?? null,
      activeTerm: termData[0] ?? null,
      classDistribution,
      recentScores: recentScores.map((s) => ({
        id: s.score.id,
        studentName: `${s.student.surname} ${s.student.firstName}`,
        subjectName: s.subject.name,
        totalScore: s.score.totalScore,
        grade: s.score.grade,
        updatedAt: s.score.updatedAt,
      })),
      classAverages: classAverages.map((c) => ({
        class: c.class,
        avgScore: c.avgScore ? Math.round(Number(c.avgScore) * 100) / 100 : 0,
      })),
      incompleteStudents: incompleteStudents.map((s) => ({
        id: s.id,
        name: `${s.surname} ${s.firstName}`,
        admissionNo: s.admissionNo,
        class: s.currentClass,
      })),
    };
  }),
});
