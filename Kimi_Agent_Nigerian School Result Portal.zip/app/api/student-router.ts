import { z } from "zod";
import { eq, and, count, desc, sql } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { students } from "@db/schema";

export const studentRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        class: z.string().optional(),
        search: z.string().optional(),
        status: z.string().optional(),
        page: z.number().default(1),
        limit: z.number().default(25),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const page = input?.page ?? 1;
      const limit = input?.limit ?? 25;
      const offset = (page - 1) * limit;

      const conditions = [];
      if (input?.class && input.class !== "All") {
        conditions.push(eq(students.currentClass, input.class as any));
      }
      if (input?.status && input.status !== "All") {
        conditions.push(eq(students.status, input.status as any));
      }
      if (input?.search) {
        const searchTerm = `%${input.search}%`;
        conditions.push(
          sql`(${students.surname} LIKE ${searchTerm} OR ${students.firstName} LIKE ${searchTerm} OR ${students.admissionNo} LIKE ${searchTerm})`
        );
      }

      const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

      const [data, totalResult] = await Promise.all([
        db
          .select()
          .from(students)
          .where(whereClause)
          .orderBy(desc(students.createdAt))
          .limit(limit)
          .offset(offset),
        db
          .select({ count: count() })
          .from(students)
          .where(whereClause),
      ]);

      return {
        students: data,
        total: totalResult[0].count,
        page,
        limit,
        totalPages: Math.ceil(totalResult[0].count / limit),
      };
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(students)
        .where(eq(students.id, input.id))
        .limit(1);
      return result[0] ?? null;
    }),

  create: publicQuery
    .input(
      z.object({
        surname: z.string().min(1),
        firstName: z.string().min(1),
        otherNames: z.string().optional(),
        gender: z.enum(["Male", "Female"]),
        dateOfBirth: z.string().optional(),
        currentClass: z.enum([
          "Pre-Nursery", "Nursery 1", "Nursery 2",
          "Primary 1", "Primary 2", "Primary 3", "Primary 4", "Primary 5", "Primary 6",
          "JSS 1", "JSS 2", "JSS 3",
          "SSS 1", "SSS 2", "SSS 3",
        ]),
        sessionAdmitted: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Generate admission number: MER/YYYY/XXXX
      const year = new Date().getFullYear();
      const countResult = await db
        .select({ count: count() })
        .from(students);
      const seq = String(countResult[0].count + 1).padStart(4, "0");
      const admissionNo = `MER/${year}/${seq}`;

      const result = await db.insert(students).values({
        admissionNo,
        surname: input.surname,
        firstName: input.firstName,
        otherNames: input.otherNames || null,
        gender: input.gender,
        dateOfBirth: input.dateOfBirth ? new Date(input.dateOfBirth) : null,
        currentClass: input.currentClass,
        sessionAdmitted: input.sessionAdmitted || `${year}/${year + 1}`,
        status: "Active" as const,
      });

      return { id: Number(result[0].insertId), admissionNo };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        surname: z.string().min(1).optional(),
        firstName: z.string().min(1).optional(),
        otherNames: z.string().optional(),
        gender: z.enum(["Male", "Female"]).optional(),
        dateOfBirth: z.string().nullable().optional(),
        currentClass: z.enum([
          "Pre-Nursery", "Nursery 1", "Nursery 2",
          "Primary 1", "Primary 2", "Primary 3", "Primary 4", "Primary 5", "Primary 6",
          "JSS 1", "JSS 2", "JSS 3",
          "SSS 1", "SSS 2", "SSS 3",
        ]).optional(),
        status: z.enum(["Active", "Graduated", "Transferred", "Withdrawn"]).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...updateData } = input;

      // Remove undefined values and convert date
      const cleanData: Record<string, unknown> = Object.fromEntries(
        Object.entries(updateData).filter(([, v]) => v !== undefined)
      );
      if (cleanData.dateOfBirth !== undefined) {
        cleanData.dateOfBirth = cleanData.dateOfBirth ? new Date(cleanData.dateOfBirth as string) : null;
      }

      await db
        .update(students)
        .set(cleanData)
        .where(eq(students.id, id));

      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(students).where(eq(students.id, input.id));
      return { success: true };
    }),

  count: publicQuery.query(async () => {
    const db = getDb();
    const result = await db.select({ count: count() }).from(students);
    return result[0].count;
  }),

  countByClass: publicQuery.query(async () => {
    const db = getDb();
    const result = await db
      .select({
        class: students.currentClass,
        count: count(),
      })
      .from(students)
      .where(eq(students.status, "Active"))
      .groupBy(students.currentClass);
    return result;
  }),
});
