import { z } from "zod";
import { eq } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { schoolSettings, gradingScale } from "@db/schema";

export const settingsRouter = createRouter({
  // School Settings
  getSchoolSettings: publicQuery.query(async () => {
    const db = getDb();
    const settings = await db
      .select()
      .from(schoolSettings)
      .limit(1);
    return settings[0] ?? null;
  }),

  updateSchoolSettings: publicQuery
    .input(
      z.object({
        schoolName: z.string().optional(),
        address: z.string().optional(),
        phone: z.string().optional(),
        email: z.string().optional(),
        website: z.string().optional(),
        motto: z.string().optional(),
        principalName: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const existing = await db
        .select()
        .from(schoolSettings)
        .limit(1);

      const cleanData = Object.fromEntries(
        Object.entries(input).filter(([, v]) => v !== undefined)
      );

      if (existing[0]) {
        await db
          .update(schoolSettings)
          .set(cleanData)
          .where(eq(schoolSettings.id, existing[0].id));
      } else {
        await db.insert(schoolSettings).values(cleanData);
      }

      return { success: true };
    }),

  // Grading Scale
  getGradingScale: publicQuery.query(async () => {
    const db = getDb();
    return db
      .select()
      .from(gradingScale)
      .orderBy(gradingScale.minScore);
  }),

  updateGradingScale: publicQuery
    .input(
      z.array(
        z.object({
          id: z.number(),
          grade: z.string(),
          minScore: z.number(),
          maxScore: z.number(),
          remark: z.string(),
        })
      )
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      for (const grade of input) {
        await db
          .update(gradingScale)
          .set({
            grade: grade.grade,
            minScore: grade.minScore,
            maxScore: grade.maxScore,
            remark: grade.remark,
          })
          .where(eq(gradingScale.id, grade.id));
      }

      return { success: true };
    }),

  resetGradingScale: publicQuery.mutation(async () => {
    const db = getDb();
    await db.delete(gradingScale);
    await db.insert(gradingScale).values([
      { grade: "A", minScore: 70, maxScore: 100, remark: "Excellent" },
      { grade: "B", minScore: 60, maxScore: 69, remark: "Good" },
      { grade: "C", minScore: 50, maxScore: 59, remark: "Credit" },
      { grade: "D", minScore: 45, maxScore: 49, remark: "Pass" },
      { grade: "E", minScore: 40, maxScore: 44, remark: "Fair" },
      { grade: "F", minScore: 0, maxScore: 39, remark: "Fail" },
    ]);
    return { success: true };
  }),
});
